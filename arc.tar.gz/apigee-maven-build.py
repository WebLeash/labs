#!/bin/env python

import argparse
import os
import base64
from buildRunner import cmdRunner
from helpers     import *

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Standard Maven build for UK apigee Applications.')
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-a', '--approot',           default='')
parser.add_argument('-U', '--update-parent',     default=True,  type=str2bool)
parser.add_argument('-P', '--update-property',   default=True,  type=str2bool)
parser.add_argument('-A', '--update-appversion', default=True,  type=str2bool)
parser.add_argument('-N', '--use-nexus3-npm',    default=False, type=str2bool)
parser.add_argument('-n', '--npm-root-dir',      default='')

options = vars(parser.parse_args())

commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard Maven build for UK apigee Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    Update parent version ..... {0[update_parent]}
    Update property versions .. {0[update_property]}
    Update application version  {0[update_appversion]}
    NPM use Nexus 3 repository  {0[use_nexus3_npm]}
    NPM root directory ........ {0[npm_root_dir]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

cmdOpts = ''

# Use Nexus 3 as the NPM repository if selected

if(options['use_nexus3_npm']):
    dctVariables = {
        "NEXUS3_USERNAME":   "nexusUser",
        "NEXUS3_PASSWORD":   "nexusPass"}

    envVars = getEnvironmentVars(dctVariables)

    # Build an .npmrc file for the project
    npmRootDir = os.path.join(approot, options['npm_root_dir'])
    npmRepo    = '{0[nexus_base_url]}/{0[nexus_npm_proxy]}\n'.format(commonVars)

    buildNpmrc(envVars['nexusUser'], envVars['nexusPass'], npmRootDir, npmRepo)

    # Set maven options
    cmdOpts += ' -Dfrontend.npm.npmInheritsProxyConfigFromMaven=false'

################################################################################

# Update the parent pom version

if(options['update_parent']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-parent')

# Update properties to the latest version of dependencies

if(options['update_property']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-properties')

# Update the main application version

if(options['update_appversion']):
    cmdRunner(approot, workEnv, 'mvn -e versions:set')

# Install Node / NPM and run Istanbul to produce code coverage report

cmdRunner(approot, workEnv, 'mvn -e test -Dswagger.exec.skip=true' + cmdOpts)

# Don't worry about "skip tests" - we have proven that tests run cleanly in the previous stage.

cmdRunner(approot, workEnv, 'mvn -e package -DskipTests')

# Run SonarQube analysis

cmdLine = 'mvn -e org.sonarsource.scanner.maven:sonar-maven-plugin:{0}:sonar ' \
        '-Dsonar.javascript.lcov.reportPaths=coverage/lcov.info ' \
        '-Dsonar.buildbreaker.skip=true '
cmdLine = cmdLine.format(commonVars['sonar_version'])

cmdRunner(approot, workEnv, cmdLine, 'SonarQube integration')
