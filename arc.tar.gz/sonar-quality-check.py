#! /bin/env python

from requests.auth import HTTPBasicAuth
from time import sleep

import sys, os, argparse
import requests, json

workDir = os.getcwd()

parser  = argparse.ArgumentParser(description='Check SonarQube Quality Gate.')
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-a', '--approot',           default='')
parser.add_argument('-r', '--report-path',       default='target/sonar')
parser.add_argument('-s', '--sonar-token',       default='')

options = vars(parser.parse_args())

################################################################################
# Headline summary output

strOut = '''\n
    Check for SonarQube Quality gate status.

    Running from {0} with options.

    App root directory ........ {1}
    Sonar report path ......... {2}
\n'''.format(options['workspace'], options['approot'], options['report_path'])
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################

def readReportTask(fileName):
	sonarData = {}
	with open(fileName) as objFile:
		for strLine in objFile:
			name, var = strLine.partition("=")[::2]
			sonarData[name.strip()] = var.strip()

	return sonarData

################################################################################

def pollTaskStatus(serverUrl, ceTaskId, basicAuth):
	print("Polling SonarQube taskId '{0}'".format(ceTaskId))

	reqURL  = '{0}/api/ce/task?id={1}'.format(serverUrl, ceTaskId)
	arrPend = ['PENDING', 'IN_PROGRESS']

	# Set up the poll loop and wait for the task to complete
	while True:
		sleep(0.1)
		response = requests.get(reqURL, auth=basicAuth)
		if(response.status_code <> 200):
			print("Received status code '{0}', failing.".format(response.status_code))
			return -1

		# Pull out the JSON formatted task information
		respJSON = response.json()
		taskJSON = respJSON['task']

		# If the task has finished (in whatever state), break the loop
		if(taskJSON['status'] not in arrPend):
			break

	if(taskJSON['status'] != 'SUCCESS'):
		print("The task has reported a status of '{0}', failing".format(taskJSON['status']))
		return -1

	# Return the Analysis ID (as this is needed for the next step)
	return taskJSON['analysisId']

################################################################################

def getStatus(serverUrl, analysisId, basicAuth):
	print("Reading Analysis result for analysisId '{0}'".format(analysisId))

	reqURL   = '{0}/api/qualitygates/project_status?analysisId={1}'.format(serverUrl, analysisId)
	response = requests.get(reqURL, auth=basicAuth)

	if(response.status_code <> 200):
		print("Received status code '{0}' retrieving analysis, failing.".format(response.status_code))
		return -1

	respJSON = response.json()
	statJSON = respJSON['projectStatus']

	return respJSON['projectStatus']['status']

################################################################################

reportFile = os.path.join(approot, options['report_path'], 'report-task.txt')
reportFile = os.path.normpath(reportFile)

sonarData = readReportTask(reportFile)
basicAuth = HTTPBasicAuth(options['sonar_token'], '')

# Poll the task status and exit with error if it doesn't succeed
analysisId = pollTaskStatus(sonarData['serverUrl'], sonarData['ceTaskId'], basicAuth)
if(analysisId == -1):
	sys.exit(1)

# Check the Quality Gate result and exit with error if it failed
status = getStatus(sonarData['serverUrl'], analysisId, basicAuth)

print('Quality gate status: {0}'.format(status))

if(status not in ['OK', 'WARN']):
	print(' - Failing the build.')
	sys.exit(1)
