
import json
import requests
import time
import base64
###import PyCrypto
import pprint

baseURL = 'https://api.enterprise.apigee.com/v1/organizations'
authURL = 'https://login.apigee.com/oauth/token'

################################################################################
# Custom error classes

class ApigeeError(Exception):
    pass

class MissingParameterError(ApigeeError):
    pass

################################################################################
# Main ApigeeUtils class

class ApigeeUtils(object):

    ############################################################################

    def __init__(self):
        self.__accessToken  = None
        self.__tokenExpiry  = 0
        self.__refreshToken = None
        self.__webProxy     = None

        self.__organisation = None
        self.__environment  = None

################################################################################

    ############################################################################
    # Requests helper for JSON queries

    def __jsonQuery(self, method, *args, **kwargs):
        # Augment kwargs with any extra config we need
        kwargs = self.__injectOptions(kwargs)

        # call requests function specified by the method
        objResp = requests.request(method, *args, **kwargs)

        # Wrap the json decode in a try/except and handle any failure
        try:
            objJson = objResp.json()
        except:
            print('Unable to decode the JSON response')
            print(' - Status Code {0}\nRaw text:'.format(objResp.status_code))
            print(objResp.text)
            return None

        # Return the status and json contents
        return { 'status_code': objResp.status_code, 'json': objJson }

    ############################################################################
    # Options injector for calls to the REST api

    def __injectOptions(self, kwargs):
        # Inject proxy config if required
        if(self.__webProxy is not None):
            if('proxies' not in kwargs):
                kwargs['proxies'] = self.__webProxy

        # Add header dict if not passed
        if('headers' not in kwargs):
            kwargs['headers'] = {}

        # Inject authentication depending on the class state
        if(self.__accessToken is not None):
            if('Authorization' not in kwargs['headers']):
                authHeader = { 'Authorization': self.__authHeader }
                kwargs['headers'].update(authHeader)

        # Make sure we're asking for a JSON response
        if('Accept' not in kwargs['headers']):
            kwargs['headers']['Accept'] = 'application/json'

        return kwargs

    ############################################################################
    # Helper for REST GET operations

    def __getEndpoint(self, endpoint, *args, **kwargs):
        if(self.__organisation is None):
            return None

        # Add baseURL and org name to the endpoint to get the full URL
        reqURL = '{0}/{1}/{2}'
        reqURL = reqURL.format(baseURL, self.__organisation, endpoint)

        return self.__jsonQuery('get', reqURL, *args, **kwargs)

    ############################################################################
    # Helper for REST POST operations

    def __postEndpoint(self, endpoint, *args, **kwargs):
        if(self.__organisation is None):
            return None

        # Add baseURL and org name to the endpoint to get the full URL
        reqURL = '{0}/{1}/{2}'
        reqURL = reqURL.format(baseURL, self.__organisation, endpoint)

        return self.__jsonQuery('post', reqURL, *args, **kwargs)

    ############################################################################
    # Helper for REST DELETE operations

    def __deleteEndpoint(self, endpoint, *args, **kwargs):
        if(self.__organisation is None):
            return None

        # Add baseURL and org name to the endpoint to get the full URL
        reqURL = '{0}/{1}/{2}'
        reqURL = reqURL.format(baseURL, self.__organisation, endpoint)

        return self.__jsonQuery('delete', reqURL, *args, **kwargs)

################################################################################

    ############################################################################
    # Helper functions to request / renew access token

    def __getAuthToken(self, authData):
        authHeaders = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json;charset=utf-8',
            'Authorization': 'Basic ZWRnZWNsaTplZGdlY2xpc2VjcmV0' }

        authResp = self.__jsonQuery('post', authURL,
                    headers = authHeaders, data = authData)

        if(authResp is None):
            return False

        if(authResp['status_code'] == 200):
            self.__accessToken  = authResp['json']['access_token']
            self.__refreshToken = authResp['json']['refresh_token']

            # Calculate the expiry time from the auth response
            intExp = int(time.time()) + authResp['json']['expires_in']

            self.__tokenExpiry  = intExp # self.__getTokenExpiry()
            return True
        else:
            print('Status Code - {0}'.format(authResp['status_code']))
            print(json.dumps(authResp['json'], indent = 4))
            return False

    ############################################################################

    def __checkAuth(self):
        # Check if the token is close to expiring - if < 5 minutes left, renew
        currTime = int(time.time())
        expTime  = self.__tokenExpiry - 300
        if(currTime < expTime):
            return True

        print(' - Refreshing apigee token')

        authData = {
        'refresh_token': self.__refreshToken,
        'grant_type': 'refresh_token' }

        return self.__getAuthToken(authData)

    ############################################################################
    # Decode the JWS token to find the expiry time (unix timestamp)

    def __getTokenExpiry(self):
        arrToken  = self.__accessToken.split('.')
        strBase64 = '{0}=='.format(arrToken[1])
        jsonToken = base64.urlsafe_b64decode(strBase64)
        dctToken  = json.loads(jsonToken)
        return dctToken['exp']

################################################################################

    def __checkRequestParams(self):
        if(self.__accessToken is None):
            raise MissingParameterError('Missing Authentication credentials')

        if(self.__organisation is None):
            raise MissingParameterError('Apigee Organisation not set')

    ############################################################################
    # Handler to print out status information if the request isn't successful

    def __reportStatus(self, objResp):
        print('Status Code - {0}'.format(objResp['status_code']))
        print(json.dumps(objResp['json'], indent = 4))
        return None
        
    ############################################################################
    # Return list of apigee proxies in the organization

    def getProxyList(self):
        self.__checkRequestParams()

        objResp = self.__getEndpoint('apis')

        if(objResp is None):
            return None

        if(objResp['status_code'] != 200):
            return self.__reportStatus
        else:
            return objResp['json']

    ############################################################################
    # Return a list of revisions deployed to an environment

    def getProxyRevisions(self, apiProxyName):
        self.__checkRequestParams()

        reqEndpoint = 'apis/{0}/revisions'.format(apiProxyName)

        objResp = self.__getEndpoint(reqEndpoint)

        if(objResp is None):
            return None

        if(objResp['status_code'] != 200):
            return self.__reportStatus(objResp)

        return objResp['json']

    ############################################################################
    # To get the deployed revision number of a proxy in an environment

    def getDeployedApiRevision(self, apigeeEnv, apiProxyName):
        self.__checkRequestParams()

        reqEndpoint = 'environments/{0}/apis/{1}/deployments'
        reqEndpoint = reqEndpoint.format(apigeeEnv, apiProxyName)

        objResp = self.__getEndpoint(reqEndpoint)

        if(objResp is None):
            return None

        # Gracefully handle a status of 400 when the proxy isn't deployed
        if(objResp['status_code'] == 400 and objResp['json']['code'] == 'distribution.ApplicationNotDeployed'):
            return 0

        if(objResp['status_code'] != 200):
            return self.__reportStatus(objResp)

        revisions = []

        for dctRevision in objResp['json']['revision']:
            if(dctRevision['state'] == 'deployed'):
                revisions.append(int(dctRevision['name']))

        # Return raw value if there's only one revision deployed
        if(len(revisions) == 1):
            return revisions[0]
        else:
            return revisions

    ############################################################################
    # Import API proxy in an organization

    def importApi(self, apiProxyName, fileName):
        self.__checkRequestParams()

        reqEndpoint = 'apis?action=import&name={0}&validate=true'
        reqEndpoint = reqEndpoint.format(apiProxyName)
        files       = {'file': open(fileName, 'rb')}

        objResp = self.__postEndpoint(reqEndpoint, files = files)

        if(objResp is None):
            return None

        if(objResp['status_code'] == 201):
            return objResp['json']['revision']
        else:
            return self.__reportStatus(objResp)

    ############################################################################
    # Deploy API in an environment

    def deployApiRevision(self, apigeeEnv, apiProxyName, revision, seamless=False):
        self.__checkRequestParams()

        reqHeaders  = {'Content-Type': 'application/x-www-form-urlencoded' }
        reqEndpoint = 'environments/{0}/apis/{1}/revisions/{2}/deployments'
        reqEndpoint = reqEndpoint.format(apigeeEnv, apiProxyName, revision)

        reqData = {}
        if(seamless):
            reqData = { 'override': True, 'delay': 15 }

        objResp = self.__postEndpoint(reqEndpoint, data = reqData, headers = reqHeaders)

        if(objResp is None):
            return None

        if(objResp['status_code'] != 200):
            return self.__reportStatus(objResp)

        return objResp['json']

    ############################################################################
    # Undeploy API from environment

    def undeployRevision(self, apigeeEnv, apiProxyName, revision):
        self.__checkRequestParams()

        reqEndpoint = 'environments/{0}/apis/{1}/revisions/{2}/deployments'
        reqEndpoint = reqEndpoint.format(apigeeEnv, apiProxyName, revision)

        objResp = self.__deleteEndpoint(reqEndpoint)

        if(objResp is None):
            return None

        if(objResp['status_code'] != 200):
            return self.__reportStatus(objResp)

        return objResp['json']

    ############################################################################
    # To delete proxy revision from an environment

    def deleteApiRevision(self, apiProxyName, revision):
        self.__checkRequestParams()

        reqEndpoint = 'apis/{0}/revisions/{1}'
        reqEndpoint = reqEndpoint.format(apiProxyName, revision)

        objResp = self.__deleteEndpoint(reqEndpoint)

        if(objResp is None):
            return None

        if(objResp['status_code'] != 200):
            return self.__reportStatus(objResp)

        return objResp['json']

################################################################################

    ############################################################################
    # Aggregate function to find the deployed version of a proxy

    def findProxyRevision(self, apigeeEnv, proxyName):
        proxyList = self.getProxyList()

        # If there's a failure, return None
        if(proxyList is None):
            return None

        # Find the deployed version - return -1 if it doesn't exist
        if(proxyName in proxyList):
            return self.getDeployedApiRevision(apigeeEnv, proxyName)
        else:
            return -1

################################################################################

    ############################################################################

    def setAuth(self, apigeeUser, apigeePass):
        authData = {
            'username': apigeeUser,
            'password': apigeePass,
            'grant_type': 'password' }

        return self.__getAuthToken(authData)

    ############################################################################
    # Class properties - INTERNAL

    @property
    def __authHeader(self):
        # return error if no token has been requested
        if(self.__accessToken == None):
            return -1

        # Check if the current token has expired
        self.__checkAuth()

        return 'Bearer {0}'.format(self.__accessToken)

    ############################################################################
    # Class properties - EXTERNAL setters

    @property
    def webProxies(self):
        return 0

    @webProxies.setter
    def webProxies(self, value):
        self.__webProxy = value

    @property
    def organisation(self):
        return self.__organisation

    @organisation.setter
    def organisation(self, value):
        self.__organisation = value

    @property
    def environment(self):
        return self.__environment

    @environment.setter
    def environment(self, value):
        self.__environment = value

    ############################################################################
    # Class properties - EXTERNAL - derivatives

    @property
    def token(self):
        # return error if no token has been requested
        if(self.__accessToken == None):
            return -1

        # Check if the current token has expired
        self.__checkAuth()

        return self.__accessToken
