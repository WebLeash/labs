#!/usr/bin/env bash

########################################################################################################
# script name: installApplication.sh
# Description: This script will install micro service RPM into *nix server using ssh.
# Parameters : This shell script can accept these many parameters
#       -a : Application Name                      : (e.g. - http-cache-server )
#       -v : version                               : (e.g. - 1.0.0 )
#       -e : Environment                           : (e.g. - acceptance )
#       -s : Service Name (optional)               : (e.g. - http-cache-server )
#       -r : Region (required for prod environment): (e.g. - <blue|green> )
#       -p : Environment Properties File Path(optional)  : (e.g. - /opt/esg/config/profile.properties )
#       -u : username to run the script : (e.g. - appmgr/spmgr)
#       -L : Liquibase profile File Path(optional)  : (e.g. /opt/esg/config/esg-insurance.properties)
#       -R : RPM repo  : (e.g. uk-rpm-release|sp-rpm-releases)
# Needed these parameters when there is a Legacy application deployment
#       -l : Is it a legacy application deployment? : (e.g. - Y/N)
#       -c : Config RPM name : (e.g. - sf-xmlcpulink-config-packaging)
#       -h : Primary servername from haproxy config(backend/servername) : (e.g. xmlcpulink/xmlcpulink_1)
#       -b : Primary servername from haproxy config(backend/servername) : (e.g. xmlcpulink/xmlcpulink_2)
#       -f : Server 1 on which application needs to be deployed : (e.g. uwfd1lc9a001.app.c9.equifax.com) 
#       -t : Server 2 on which application needs to be deployed : (e.g. udlt1lc9a001.app.c9.equifax.com)
#       -n : tomcat server name
#       -w : Is it a batch implementation? : (e.g. - Y/N, Y if haproxy is not required)
#       -x : Is tomcat? : (e.g. - Y/N, Y if the deployment server is tomcat)
#########################################################################################################


###############################################################################
#
# fun_print()
# Description : Prints line into log file
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to print in log file
#
###############################################################################

fun_print() {
	message=$1
	echo "`date` : $message"
}
###############################################################################
# End of fun_print()
###############################################################################


###############################################################################
#
# rc_check()
# Description: Check the return code and exit with message on failure
# Parameters:
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to print on failure
#
###############################################################################

rc_check() {
	if [ $? != 0 ] ; then

		fun_print "$@"
		exit -1
	fi
}

###############################################################################
# End of rc_check()
###############################################################################

#-----------------------
# Setup the environment |
# ----------------------
commandusage="Usage: $0 -a <Application Name> -v <Version> -e <Environment> -s <Service Name> [-r <blue|green>] [-R < RPM Releases Repo>][-p <Environment Properties File Path>] [-L <Liquibase File Path>][-l <isLegacy>][ -c <configRPMName>][-h <Haproxy main Server] [-b <Haproxy Backup Server>] [-f<First Deploy Server>] [-t<Trivial(second) Deploy Server>] [-n <Tomcat Server Name>] [-w <isBatch>] [-x <isTomcat>] [-u <username appmgr|spmgr> ]"

# find location of scripts
scriptDir=$(dirname $0)
if [ $scriptDir = "." ]; then
	scriptDir=$(pwd)
fi


DATE=`date "+%d-%h-%Y"`;export DATE

fun_print "---------------------------------------------------------------------------------------------"
fun_print "$0 started"

# Validation of parameters
applicationName=""
version=""
serviceName=""
environment=""
region=""
profile=""
isLegacy=""
configName=""
haproxy_1=""
haproxy_2=""
deployserver1=""
deployserver2=""
tomcatserver=""
isBatch=""
isTomcat=""
userName="appmgr"
rpm_releases_repo="uk-rpm-releases"
liquibase_profile_path=""

while getopts a:v:e:s:r:p:l:c:h:b:f:t:n:w:x:u:R:L: option;
do
	case $option in
	a) applicationName=$OPTARG;;
	v) version=$OPTARG;;
	e) environment=$OPTARG;;
	s) serviceName=$OPTARG;;
	r) region=$OPTARG;;
	p) profile=$OPTARG;;
	l) isLegacy=$OPTARG;;
	c) configName=$OPTARG;;
	h) haproxy_1=$OPTARG;;
	b) haproxy_2=$OPTARG;;
	f) deployserver1=$OPTARG;;
	t) deployserver2=$OPTARG;;
	n) tomcatserver=$OPTARG;;
	w) isBatch=$OPTARG;;
	x) isTomcat=$OPTARG;;
	u) userName=$OPTARG;;
	R) rpm_releases_repo=$OPTARG;;
	L) liquibase_profile_path=$OPTARG;;
	?) fun_print $commandusage
		exit 1
	;;
	esac
done

if [ "$applicationName" = "" ]; then
	fun_print "Please provide valid Application Name"
	fun_print "$commandusage"
	exit 1
fi

if [ "$version" = "" ]; then
	fun_print "Please provide valid version"
	fun_print "$commandusage"
	exit 1
fi

if [ "$environment" = "" ]; then
	fun_print "Please provide valid environment"
	fun_print "$commandusage"
	exit 1
fi

#Checking condition : If username is other than appmgr or spmgr then quiting the script
if [ "${userName}" != "appmgr" -a "${userName}" != "spmgr" ]; then
	fun_print "Please provide valid username"
	fun_print "$commandusage"
	exit 1
fi

#Checking condition : If rpm_release_repo is other than uk-rpm-releases or sp-rpm-releases then quiting the script
if [ "${rpm_releases_repo}" != "uk-rpm-releases" -a "${rpm_releases_repo}" != "sp-rpm-releases" ]; then
	fun_print "Please provide valid rpm releases repo"
	fun_print "$commandusage"
	exit 1
fi

if [ "$isLegacy" != "" -a "$isLegacy" != " " ]; then
	if [ "$isLegacy" != "N" ]; then
		isLegacy="Y"
	fi
else
	isLegacy="N"
fi

if [ "$isBatch" != "" -a "$isBatch" != " " ]; then
	if [ "$isBatch" != "N" ]; then
		isBatch="Y"
	fi
else
	isBatch="N"
fi

if [ "$isTomcat" != "" -a "$isTomcat" != " " ]; then
	if [ "$isTomcat" != "N" ]; then
		isTomcat="Y"
	fi
else
	isTomcat="N"
fi

if [ "$isLegacy" = "Y" ]; then
	log_file=deployment."$DATE".log
	export log_file
fi

# For acceptance and CIT environment, legacy applications are usually deployed onto a single server
if [ "$isLegacy" = "Y" ]; then
	if [ "$deployserver1" = "" ]; then
		fun_print "Please provide server name on which Legacy application needs to be deployed."
		fun_print "$commandusage"
		exit 1
	fi
	
	if [ "$haproxy_1" = "" -a "$isBatch" = "N" ]; then
		fun_print "Please provide primary haproxy server name."
		fun_print "$commandusage"
		exit 1
	fi
fi

#Checking condition : If isTomcat flag is true, the tomcat server name should not be blank.
if [ "$isTomcat" = "Y" ]; then
	if [ "$tomcatserver" = "" ]; then
		fun_print "If isTomcat flag is true, the tomcat server name should not be blank"
		fun_print "$commandusage"
		exit 1
	fi
fi

#find location of execution where host files are stored
if [ -d "$scriptDir/$applicationName" ]; then
	host_dir=$scriptDir
else
	host_dir=$(pwd)
fi

# Move logic to allow remote stop/start of HAProxy from installOnLinux to here
if [ "$isLegacy" = "Y" -a "$isBatch" = "N" ]; then
	remoteManageHA="Y"
else
	remoteManageHA="N"
fi

if [ "$isLegacy" = "N" ]; then
	if [ "$environment" = "prod" ]; then
		if [ "$region" = "blue" -o "$region" = "green" ]; then
			host_file_path=$host_dir/$applicationName/$environment/$region/hosts.txt
		else
			fun_print "Please provide valid production region"
			fun_print "$commandusage"
			exit 1
		fi
	elif [ "${environment}" = "cit" ] && [ "${region}" = "blue" -o "${region}" = "green" ]; then
		host_file_path=$host_dir/${applicationName}/${environment}/${region}/hosts.txt
	else
		host_file_path=$host_dir/$applicationName/$environment/hosts.txt
	fi

	if [ ! -f $host_file_path ]; then
		echo "Host file $host_file_path not present"
		exit -1
	else
		#trim host file for spaces and blank lines
		sed -e 's/[ \t ]//g;/^$/d' $host_file_path > $host_file_path.out
		mv  $host_file_path.out $host_file_path
	fi
fi

fun_print "Parameters"
fun_print "----------------------------------"
fun_print "applicationName : $applicationName"
fun_print "version : '$version'"
fun_print "environment : '$environment'"
fun_print "serviceName : '$serviceName'"
fun_print "Region : '$region'"
fun_print "profile : '$profile'"
fun_print "Host File Path : '$host_file_path'"
fun_print "Username is : '$userName'"
fun_print "RPM Releases Repo is : '$rpm_releases_repo'"
fun_print "Liquibase Profile Path is : '$liquibase_profile_path'"

if [ "$isLegacy" = "Y" ]; then
	fun_print "Legacy System? : '$isLegacy'"
	fun_print "Config RPM Name : '$configName'"
	fun_print "Haproxy Server 1 : '$haproxy_1'"
	fun_print "Haproxy Server 2: '$haproxy_2'"
	fun_print "Deploy Server 1: '$deployserver1'"
	fun_print "Deploy Server 2: '$deployserver2'"
	fun_print "Tomcat server name : '$tomcatserver'"
	fun_print "Is Batch : '$isBatch'"
	fun_print "Is Tomcat : '$isTomcat'"
fi

# Find application RPM before going ahead with deploy
applicationRPMurl="$(~/build-scripts/nexus-find-rpm.py -n ${applicationName} -v ${version})"
rc_check "Unable to find RPM for ${applicationName} - ${version}, so not going ahead with the deployment"

# Stage the application RPM locally
fullVersion="$(~/build-scripts/nexus-find-rpm.py --getVersion -n ${applicationName} -v ${version})"
appFileName="${applicationName}-${fullVersion}.rpm"
remotePath="/tmp/appDeploy/${applicationName}/${fullVersion}"

mkdir rpm

wget -nv --no-proxy ${applicationRPMurl} -O ./rpm/${appFileName}
rc_check "Unable to download the RPM for ${applicationName} - ${version}, aborting"

# Find and stage the config RPM if specified
if [ "$configName" != "" -a "$configName" != " " ]; then
	configRPMurl="$(~/build-scripts/nexus-find-rpm.py -n ${configName} -v ${version})"
	rc_check "Failed to find the config RPM for ${applicationName} - ${version}"

	confFileName="${configName}-${fullVersion}.rpm"
	wget -nv --no-proxy ${configRPMurl} -O ./rpm/${confFileName}
	rc_check "Unable to download the config RPM for ${applicationName} - ${version}"
fi

#For Non Legacy applications
if [ "$isLegacy" = "N" ]; then
	readarray -t hosts < "$host_file_path"
	for host in "${hosts[@]}"; do
		fun_print "Installing on $host"
		log_file=$(pwd)/"$host".installation."$DATE".log
		export log_file

		# Push the staged application RPM to the remote host
		ssh -T -o "StrictHostKeyChecking no" $userName@$host "bash -s" -- < $scriptDir/prep-install.sh "-p \"${remotePath}\""
		rc_check "Unable to create ${remotePath} on server ${host}"

		scp ./rpm/${appFileName} $userName@$host:${remotePath}/${appFileName}
		rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${host}"

		# Build the SSH command line
		ssh_args="-a \"$applicationName\" -v \"$fullVersion\" -e \"$environment\" -s \"$serviceName\""

		if [ -n "$profile" ]; then
			ssh_args+=" -p \"$profile\""
		fi

		if [ -n "$liquibase_profile_path" ]; then
			ssh_args+=" -L \"$liquibase_profile_path\""
		fi

		ssh -T -o "StrictHostKeyChecking no" $userName@$host "bash -s" -- < $scriptDir/installOnLinux.sh ${ssh_args} >> $log_file 2>&1

		if [ "$?" != "0" ]; then
			echo "Error occurred during installation of $applicationName on $host. Please check $log_file for error details" >> $log_file
			exit -1
		fi
	done
#For Legacy applications
else
	echo "Started on host : $deployserver1" >> $log_file

	# Push the staged application RPM to the remote host
	ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver1 "bash -s" -- < $scriptDir/prep-install.sh "-p \"${remotePath}\""
	rc_check "Unable to create ${remotePath} on server ${host}"

	scp ./rpm/${appFileName} $userName@$deployserver1:${remotePath}/${appFileName}
	rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${host}"

	# Push the staged config RPM if specified
	if [ "$configName" != "" -a "$configName" != " " ]; then
		scp ./rpm/${confFileName} $userName@$deployserver1:${remotePath}/${confFileName}
		rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${host}"
	fi

	#Stop the haproxy primary server from second deployment server
	if [ "$deployserver2" != "" -a "$deployserver2" != " " -a "$isBatch" = "N" ]; then
		echo "Disabling Haproxy server $haproxy_1 on host : $deployserver2" >> $log_file
		ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver2 sudo /sbin/service haproxyctl "disable server $haproxy_1" >> $log_file
		echo "Waiting for 30 seconds to stop the $haproxy_1 server" >> $log_file
		sleep 30
	fi

	echo "Started with the config and application RPM installation on host : $deployserver1" >> $log_file

	# Build the SSH command line
	ssh_args="-a \"$applicationName\" -v \"$fullVersion\" -e \"$environment\" -s \"$serviceName\" "
	ssh_args+="-c \"$configName\" -H \"$remoteManageHA\" -t \"$isTomcat\""

	if [ "$isBatch" = "Y" ]; then
		if [ "$isTomcat" = "Y" ]; then
			ssh_args+=" -n \"$tomcatserver\""
		fi
	else
		ssh_args+=" -h \"$haproxy_1\" -n \"$tomcatserver\""
	fi

	ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver1 "bash -s" -- < $scriptDir/installOnLinux.sh ${ssh_args} >> $log_file 2>&1

	if [ "$?" != "0" ]; then
		echo "Error occurred during installation of $applicationName on $host. Please check $log_file for error details" >> $log_file
		exit -1
	fi

	if [ "$deployserver2" != "" -a "$deployserver2" != " " -a "$isBatch" = "N" ]; then
		echo "Enabling Haproxy server $haproxy_1 on host : $deployserver2" >> $log_file
		ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver2 sudo /sbin/service haproxyctl "enable server $haproxy_1" >> $log_file
		echo "Waiting for 30 seconds to start the $haproxy_1 server" >> $log_file
		sleep 30
	fi

	if [ "$deployserver2" != "" -a "$deployserver2" != " " ]; then
		echo "Started on host : $deployserver2" >> $log_file

		# Push the staged application RPM to the remote host
		ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver2 "bash -s" -- < $scriptDir/prep-install.sh "-p \"${remotePath}\""
		rc_check "Unable to create ${remotePath} on server ${host}"

		scp ./rpm/${appFileName} $userName@$deployserver2:${remotePath}/${appFileName}
		rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${host}"

		# Push the staged config RPM if specified
		if [ "$configName" != "" -a "$configName" != " " ]; then
			scp ./rpm/${confFileName} $userName@$deployserver2:${remotePath}/${confFileName}
			rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${host}"
		fi

		#Stop the haproxy backup  server from first deployment server

		if [ "$isBatch" = "N" ]; then
			echo "Disabling Haproxy server $haproxy_2 on host : $deployserver1" >> $log_file
			ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver1 sudo /sbin/service haproxyctl "disable server $haproxy_2" >> $log_file
			echo "Waiting for 30 seconds to stop the $haproxy_2 server" >> $log_file
			sleep 30
		fi
		echo "Started with the config and application RPM installation on host : $deployserver2" >> $log_file

		# Build the SSH command line
		ssh_args="-a \"$applicationName\" -v \"$fullVersion\" -e \"$environment\" -s \"$serviceName\" "
		ssh_args+="-c \"$configName\" -H \"$remoteManageHA\" -t \"$isTomcat\""
		if [ "$isBatch" = "Y" ]; then
			if [ "$isTomcat" = "Y" ]; then
				ssh_args+=" -n \"$tomcatserver\""
			fi
		else
			ssh_args+=" -h \"$haproxy_2\" -n \"$tomcatserver\""
		fi

		ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver2 "bash -s" -- < $scriptDir/installOnLinux.sh ${ssh_args} >> $log_file 2>&1

		if [ "$?" != "0" ]; then
			echo "Error occurred during installation of $applicationName on $host. Please check $log_file for error details" >> $log_file
			exit -1
		fi

		if [ "$isBatch" = "N" ]; then
			echo "Enabling Haproxy server $haproxy_2 on host : $deployserver1" >> $log_file
			ssh -T -o "StrictHostKeyChecking no" $userName@$deployserver1 sudo /sbin/service haproxyctl "enable server $haproxy_2"	>> $log_file
		fi
	fi
fi

