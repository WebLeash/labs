#!/usr/bin/env bash


workspace=$(pwd)

DATE=`date "+%d-%h-%Y"`;export DATE

: "${BB_DEPLOYER_USER:=DEFAULT_VALUE}"

proxy_env_name=""
app_name=""
organization_name=""
region=""

usage()
{
cat << EOF
usage: $0 options

Chef Active environment script.


OPTIONS:
  
  -e : Proxy Envrionment name                      : (e.g. bbuk_idams_proxy_env_bat )
  -a : Application Name                            : (e.g. idams )
  -o : Organization Name                           : (e.g. it-intl-it-uk-id-non-prod)
  -r : Region                                      : (e.g. staging or live )
EOF
}


while getopts e:a:o:r: option; do
    case "$option" in
	    e) proxy_env_name=$OPTARG;;
		a) app_name=$OPTARG;;
		o) organization_name=$OPTARG;;
		r) region=$OPTARG;;
	    ?) usage
           exit 1;;
    esac
done

if [ -z "${proxy_env_name}" -o -z "${app_name}"  -o -z "${organization_name}" -o -z "${region}" ] ; then
    usage
    exit 1
fi

cat << EOF

    Get active environment for BlueBird.

    Proxy Envrionment name .....  ${proxy_env_name}
    Application name ...........  ${app_name}
	Organization Name ..........  ${organization_name}
    Region .....................  ${region}
EOF

#Exporting required variables for Chef 

export NODE_NAME=$BB_DEPLOYER_USER
export CLIENT_KEY=~/.chef/${NODE_NAME}_chef_key.pem
export VAL_CLIENT_NAME=${organization_name}
export VAL_KEY=~/.chef/${organization_name}-validator
export CHEF_SERVER_URL=https://chef-server.app.c9.equifax.com/organizations/${organization_name}
export OS_USERNAME=$BB_DEPLOYER_USER

cd "${workspace}"

echo "Tidying the workspace"
rm -f staging-color.txt

echo "Running from ${workspace}"

log_file=$(pwd)/"$HOSTNAME".deployment."$DATE".log

active_region=`scl enable rh-ruby23 "ruby ~/chef-scripts/environment_control/bin/get_live_sub_env.rb ${proxy_env_name} ${app_name};"`
    if [ $? -ne 0 ] ; then
       echo "ABORTING. Could not get the active environment."
       exit 1
    fi



case ${region}:${active_region} in
  live:*)
    echo ${active_region} > staging-color.txt
  ;;
  staging:blue)
    echo green > staging-color.txt
  ;;
  staging:green)
    echo blue > staging-color.txt
  ;;
  *)
    exit 1
esac
