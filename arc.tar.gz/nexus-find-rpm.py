#!/bin/env python

import os
import argparse
import requests
import xmltodict

from requests.auth import HTTPBasicAuth
from nexus3Search  import nexus3Search
from helpers       import *

searchURL2 = 'http://repo.devcentral.equifax.com/yum/service/local'
repoURL2   = 'http://repo.devcentral.equifax.com/yum/content/repositories'

commonVars = getCommonVars()
nexus3Host = commonVars['nexus_host']
repoURL3   = 'http://lab0.devtools.ntg.equifax.com/repository'

parser  = argparse.ArgumentParser(description='RPM Finder for UK Applications.')
parser.add_argument('-n', '--name',    default='')
parser.add_argument('-v', '--version', default='')
parser.add_argument('--getVersion',    action='store_true')
options = vars(parser.parse_args())

dctVariables = {
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"}

envVariables = getEnvironmentVars(dctVariables)

################################################################################

def searchNexus3(strName, strVersion, basicAuth):
    objSearch = nexus3Search(nexus3Host)
    objSearch.basicAuth = basicAuth

    if(objSearch.searchName(strName) != 0):
        return -1

    if(len(objSearch) < 1):
        return -1

    dctArtifact = objSearch.findVersion(strVersion, 'rpm')

    if(dctArtifact == None):
        return -1

    return dctArtifact

################################################################################

def searchNexus2(strName, strVersion):
    reqURL  = '{0}/lucene/search?q={1}'.format(searchURL2, strName)
    xmlResp = requests.get(reqURL)
    xmlDict = xmltodict.parse(xmlResp.content)

    # Return -1 if there are no results
    if(int(xmlDict['searchNGResponse']['totalCount']) == 0):
        return -1

    coordV = ''
    for artifact in xmlDict['searchNGResponse']['data']['artifact']:
        if(strName == artifact['artifactId'] and strVersion in artifact['version']):
            repoName = artifact['artifactHits']['artifactHit']['repositoryId']
            coordG   = artifact['groupId']
            coordA   = artifact['artifactId']
            coordV   = artifact['version']

    # Return -1 if there is no version match
    if(coordV == ''):
        return -1

    reqURL  = '{0}/repositories/{1}/index_content/'.format(searchURL2, repoName)
    reqURL += '?groupIdHint={0}&artifactIdHint={1}&versionHint={2}'.format(coordG, coordA, coordV)

    xmlResp = requests.get(reqURL)
    xmlDict = xmltodict.parse(xmlResp.content)
    xmlNode = xmlDict['indexBrowserTreeViewResponse']['data']

    # Walk the XML tree to find the artifact path
    while True:
        if(xmlNode['type'] == 'artifact'):
            break
        xmlNode = xmlNode['children']['indexBrowserTreeNode']

    return { 'repository': repoName,
             'coords': { 'g': coordG, 'a': coordA, 'v': coordV },
             'path': xmlNode['path'] }

################################################################################

reqAuth = HTTPBasicAuth(envVariables['nexusUser'], envVariables['nexusPass'])
result  = searchNexus3(options['name'], options['version'], reqAuth)
repoURL = repoURL3.format(envVariables['nexusUser'], envVariables['nexusPass'])

if(result == -1):
    result  = searchNexus2(options['name'], options['version'])
    repoURL = repoURL2

if(result == -1):
    exit(1)

# Output switch - either provide version or download link
if(options['getVersion'] == True):
    print(result['coords']['v'])
else:
    downloadURL = '{0}/{1[repository]}/{1[path]}'.format(repoURL, result)
    print(downloadURL)
