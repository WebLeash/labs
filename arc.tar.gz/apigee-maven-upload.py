#!/bin/env python

import argparse
import os
import base64
from buildRunner import cmdRunner
from helpers     import *
import xmltodict

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Standard Maven upload for UK apigee Applications.')
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-a', '--approot',           default='')
parser.add_argument('-U', '--update-parent',     default=True,  type=str2bool)
parser.add_argument('-P', '--update-property',   default=True,  type=str2bool)
parser.add_argument('-A', '--update-appversion', default=True,  type=str2bool)
parser.add_argument('-N', '--use-nexus3-npm',    default=False, type=str2bool)
parser.add_argument('-n', '--npm-root-dir',      default='')
parser.add_argument('-D', '--deploy',            default=True,  type=str2bool)
parser.add_argument('-T', '--tag-changes',       default=True,  type=str2bool)

options = vars(parser.parse_args())

dctVariables = {
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"}

envVars    = getEnvironmentVars(dctVariables)
commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard Maven upload for UK apigee Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    Update parent version ..... {0[update_parent]}
    Update property versions .. {0[update_property]}
    Update application version  {0[update_appversion]}
    NPM use Nexus 3 repository  {0[use_nexus3_npm]}
    NPM root directory ........ {0[npm_root_dir]}
    Tag changes ............... {0[tag_changes]}
    Deploy to Nexus ........... {0[deploy]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

cmdOpts = ''

# Use Nexus 3 as the NPM repository if selected

if(options['use_nexus3_npm']):
    # Build an .npmrc file for the project
    npmRootDir = os.path.join(approot, options['npm_root_dir'])
    npmRepo    = '{0[nexus_base_url]}/{0[nexus_npm_proxy]}\n'.format(commonVars)

    buildNpmrc(envVars['nexusUser'], envVars['nexusPass'], npmRootDir, npmRepo)

    # Set maven options
    cmdOpts += ' -Dfrontend.npm.npmInheritsProxyConfigFromMaven=false'

################################################################################

# Update the parent pom version

if(options['update_parent']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-parent')

# Update properties to the latest version of dependencies

if(options['update_property']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-properties')

# Update the main application version

if(options['update_appversion']):
    cmdRunner(approot, workEnv, 'mvn -e versions:set')

# Clean the workspace and produce a clean build for upload

cmdRunner(approot, workEnv, 'mvn -e clean package -DskipTests')

# Deploy to Nexus.

if(options['deploy']):
    nexusRepo = '{0[nexus_base_url]}/{0[nexus_mvn_releases]}'.format(commonVars)

    # Read the POM file and find the app name and version
    with open(os.path.join(approot, 'pom.xml')) as fd:
        xmlDict = xmltodict.parse(fd.read())

    strName = xmlDict['project']['name']
    strVer  = xmlDict['project']['version']

    # Build the source and destination file names for API bundle
    strFile = '{0}-{1}.zip'.format(strName, strVer)
    srcFile = os.path.join(approot, 'target', strFile)

    urlDest = '{0}/com/equifax/api/{1}/{2}/{3}'
    urlDest = urlDest.format(nexusRepo, strName, strVer, strFile)

    # Build the command line and run
    cmdLine = 'curl --noproxy "*" --user {0}:{1} --upload-file {2} {3} |tee /dev/null'
    cmdLine = cmdLine.format(envVars['nexusUser'], envVars['nexusPass'], srcFile, urlDest)

    cmdRunner(approot, workEnv, cmdLine)

    # Build the source and destination file names for test scripts
    strName = '{0}-test-scripts'.format(strName)
    strFile = '{0}-{1}.zip'.format(strName, strVer)
    srcFile = os.path.join(approot, 'target', strFile)

    urlDest = '{0}/com/equifax/api/test-scripts/{1}/{2}/{3}'
    urlDest = urlDest.format(nexusRepo, strName, strVer, strFile)

    # Build the command line and run
    cmdLine = 'curl --noproxy "*" --user {0}:{1} --upload-file {2} {3} |tee /dev/null'
    cmdLine = cmdLine.format(envVars['nexusUser'], envVars['nexusPass'], srcFile, urlDest)

    cmdRunner(approot, workEnv, cmdLine)

# Tag changes using the tag-changes.sh script.

if(options['tag_changes']):
    cmdRunner(approot, workEnv, '~/build-scripts/tag-changes.sh {0}'.format(approot))

# Tidy up.

cmdRunner(approot, workEnv, 'mvn -e versions:revert')

cmdRunner(approot, workEnv, 'mvn -e clean')
