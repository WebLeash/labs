#!/usr/bin/env bash

#############################################################################################################
# script name: config-rpm-build-upload.sh
# Description: This script will generate environment specific configuration RPMs and upload it to YUM channel.
# Parameters : It accepts one parameter (if not provided, the script will end)
#			   1) Packaging type (e.g. acceptance/cit/prod)
#############################################################################################################


###############################################################################
#
# fun_print()
# Description : Echo messages which current date
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to be formatted with date
#
###############################################################################

fun_print() {
	message=$1
	echo "**********************************************************************************"
	echo "`date` : $message"
	echo "**********************************************************************************"
}
###############################################################################
# End of fun_print()
###############################################################################

if [ -z "$1" ] ; then
    echo "NO PROFILE TO BUILD.  This may or may not be an error - check if you were expecting something to happen."
    exit 0
fi

fun_print "Updating the parent version"
mvn -e -U -B versions:update-parent
if [ $? -ne 0 ] ; then
	echo "ABORTING. Versions plugin. Could not run update-parent goal."
	exit 1
fi

fun_print "Updating properties version"
mvn -e -U -B versions:update-properties
if [ $? -ne 0 ] ; then
	echo "ABORTING. Versions plugin. Could not run update-properties goal."
	exit 1
fi

fun_print "Setting up project version"
mvn -e versions:set
if [ $? -ne 0 ] ; then
	echo "ABORTING. Versions plugin. Could not run version set goal."
	exit 1
fi

fun_print "Maven build with profile $1"
mvn clean package -P $1
if [ $? -ne 0 ] ; then
	echo "ABORTING. Maven Build. Could not run specific profile $1."
	exit 1
fi

# Get component version
component_version=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.version}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting component version"
	exit 1
fi
fun_print "Component Version is $component_version"

# Get groupId
component_groupId=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.groupId}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting component group id"
	exit 1
fi
fun_print "Component group id is $component_groupId"

# Get artifactId
component_artifactId=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.artifactId}' --non-recursive exec:exec)-$1
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting component artifact Id"
	exit 1
fi
fun_print "Component artifact id is $component_artifactId"

# Get distribution management URL
component_distribution_repo_url=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.distributionManagement.repository.url}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting component distribution repository URL"
	exit 1
fi
fun_print "Component artifact id is $component_distribution_repo_url"

# Get distribution management id
component_distribution_repo_id=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.distributionManagement.repository.id}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting component distribution repository Id"
	exit 1
fi
fun_print "Component artifact id is $component_distribution_repo_id"

pushd target/rpm/$component_artifactId/RPMS/noarch > /dev/null
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in Traversing to path target/rpm/$component_artifactId/RPMS/noarch"
	exit 1
fi

fun_print "Starting with uploading the RPM"

# Force to use Maven 3.3.9 due to Nexus having proxy that doesn't like Maven 3.5.x

temp_m2_home="${M2_HOME}"
temp_maven_home="${MAVEN_HOME}"

export M2_HOME="/usr/share/maven339/apache-maven-3.3.9"
export MAVEN_HOME="/usr/share/maven339/apache-maven-3.3.9"

mvn339 deploy:deploy-file -DgroupId=$component_groupId -DartifactId=$component_artifactId -Dversion=$component_version -DgeneratePom=true -Dpackaging=rpm -DrepositoryId=$component_distribution_repo_id -Durl=$component_distribution_repo_url -Dfile=`ls *.rpm`
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in uploading RPM to YUM channel"
	exit 1
fi

# Put them back again.

export M2_HOME="${temp_m2_home}"
export MAVEN_HOME="${temp_maven_home}"

fun_print "Uploaded the RPM to YUM channel"

fun_print "Traversing back to config packaging directory"
popd > /dev/null
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in Traversing back to config packaging directory"
	exit 1
fi

fun_print "Reverting project version"
mvn -e versions:revert
if [ $? -ne 0 ] ; then
	echo "ABORTING. Versions plugin. Could not run revert goal."
	exit 1
fi

exit 0