#!/usr/bin/env bash

sonar_version="3.5.0.1254"
clover_version="4.3.1"
fod_version="3.0.8"

fod_proxy="http://172.18.100.15:18717"
apigee_proxy_host="172.22.165.31:3128"

nexus_host="nexus.uk.equifax.com"
nexus_base_url="https://nexus.uk.equifax.com/repository"
nexus_mvn_releases="uk-releases-maven-hosted"
nexus_npm_proxy="efxnpm"
