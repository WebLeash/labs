#!/bin/env python

import argparse
import os
import base64
from buildRunner import cmdRunner
from helpers     import *

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Standard Maven upload for UK Applications.')
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-a', '--approot',           default='')
parser.add_argument('-U', '--update-parent',     default=True,  type=str2bool)
parser.add_argument('-P', '--update-property',   default=True,  type=str2bool)
parser.add_argument('-A', '--update-appversion', default=True,  type=str2bool)
parser.add_argument('-N', '--use-nexus3-npm',    default=False, type=str2bool)
parser.add_argument('-n', '--npm-root-dir',      default='')
parser.add_argument('-D', '--deploy',            default=True,  type=str2bool)
parser.add_argument('-T', '--tag-changes',       default=True,  type=str2bool)
parser.add_argument('-d', '--dotdir',            default='')
parser.add_argument('-B', '--bbrelease',         default=False, type=str2bool)
parser.add_argument('-b', '--bbappname',         default='')

options = vars(parser.parse_args())

commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard Maven upload for UK Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    DOT Directory ............. {0[dotdir]}
    Update parent version ..... {0[update_parent]}
    Update property versions .. {0[update_property]}
    Update application version  {0[update_appversion]}
    NPM use Nexus 3 repository  {0[use_nexus3_npm]}
    NPM root directory ........ {0[npm_root_dir]}
    Deploy to Nexus ........... {0[deploy]}
    Tag changes ............... {0[tag_changes]}
    BB - Release Control ...... {0[bbrelease]}
    BB - Application name ..... {0[bbappname]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])
dotdir  = os.path.join(options['workspace'], options['dotdir'])

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

cmdOpts = ''

# Use Nexus 3 as the NPM repository if selected

if(options['use_nexus3_npm']):
    dctVariables = {
        "NEXUS3_USERNAME":   "nexusUser",
        "NEXUS3_PASSWORD":   "nexusPass"}

    envVars = getEnvironmentVars(dctVariables)

    # Build an .npmrc file for the project
    npmRootDir = os.path.join(approot, options['npm_root_dir'])
    npmRepo    = '{0[nexus_base_url]}/{0[nexus_npm_proxy]}\n'.format(commonVars)

    buildNpmrc(envVars['nexusUser'], envVars['nexusPass'], npmRootDir, npmRepo)

    # Set maven options
    cmdOpts += ' -Dfrontend.npm.npmInheritsProxyConfigFromMaven=false'

################################################################################

# Update the parent pom version

if(options['update_parent']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-parent')

# Update properties to the latest version of dependencies

if(options['update_property']):
    cmdRunner(approot, workEnv, 'mvn -e -U -B versions:update-properties')

# Update the main application version

if(options['update_appversion']):
    cmdRunner(approot, workEnv, 'mvn -e versions:set')

# Clean the workspace and produce a clean build for upload

cmdRunner(approot, workEnv, 'mvn -e clean install -DskipTests' + cmdOpts)

# Deploy to Nexus.

if(options['deploy']):
    cmdRunner(approot, workEnv, 'mvn -e deploy -Dmaven.test.skip=true' + cmdOpts)

# Tag changes using the tag-changes.sh script.

if(options['tag_changes']):
    cmdRunner(approot, workEnv, '~/build-scripts/tag-changes.sh {0}'.format(approot))

# Run Dependency checker in the subdirectory for the DOT processing.

cmdLine = 'mvn -e org.apache.maven.plugins:maven-dependency-plugin:3.1.0:tree ' \
    '-DoutputType="dot" -DoutputFile="/var/go/dot/\${project.build.finalName}.dot"'
cmdRunner(dotdir, workEnv, cmdLine, 'Maven dependency plugin')

# Update BB release controls

if(options['bbrelease']):
    cmdLine = '~/build-scripts/release-control-version-update.sh -r "{0}" -e "int" -a "{1}"'.format(approot, options['bbappname'])
    cmdRunner(approot, workEnv, cmdLine, 'Bluebird Release Control')

# Tidy up.

cmdRunner(approot, workEnv, 'mvn -e versions:revert')

cmdRunner(approot, workEnv, 'mvn -e clean')
