#!/usr/bin/env bash

############################################################################################################
# script name: relese-control-version-update.sh
# Description: This script will update the application build version number into release control.
# Parameters : This shell script can accept 2 parameters
# Command:/bin/sh ./release-control-version-update.sh -d application -a bbuk_xmlcpulink_env
#       -d : Application directory from material             : (e.g. - application )
#       -a : Application Name                                : (e.g. - bbuk_xmlcpulink_env )
############################################################################################################


############################################################################################################
# Function name : fun_print
# Description : This function will print the message on the console
############################################################################################################

fun_print() {
	message=$1
	echo "`date` : $message"
}

############################################################################################################
#fun_print ends
############################################################################################################

# Make the cwd that of this script
cd "$(dirname "$0")"

#Get current date and time
DATE=`date "+%d-%h-%Y"`;export DATE

# Validation of parameters

command_usage="Usage: $0 -r <applicationDirectory> -a <applicationName> -e <Environment[stag|env|int]>"

fun_print "---------------------------------------------------------------------------------------------"
fun_print "$0 started"

applicationDirectory=""
applicationName=""
environment=""

while getopts r:a:e:b: option;
do
	case ${option} in
		r) applicationDirectory=$OPTARG;;
		a) applicationName=$OPTARG;;
		e) environment=$OPTARG;;
		?) fun_print "$command_usage"
		exit 1
		;;
	esac
done

#Checking the input parameter
fun_print "Application Directory is : "$applicationDirectory
fun_print "ApplicationName is : "$applicationName
fun_print "Environment is : "$environment

#Checking if Application directory is empty
if [ -z "$applicationDirectory" ]; then
	fun_print "Please provide valid application directory name"
	exit 1
fi

#Checking if application name is empty
if [ -z "$applicationName" ]; then
	fun_print "Please provide valid application name"
	exit 1
fi

if [ ! "$environment" = "int" -o "$environment" = "env" -o "$environment" = "stag" ];then
	fun_print "Please provide valid environment. USAGE : [int||env||stag]"
    exit 1;
fi

#First go to Application directory and get the application version number
fun_print "Switching to Application directory : $applicationDirectory"
cd ..
fun_print "Current Working Directory is $(pwd)"

cd "$applicationDirectory"
fun_print "Current Working Directory is $(pwd)"

#Get maven project version in COMPONENT_VERSION 
COMPONENT_VERSION=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.version}' --non-recursive exec:exec)
fun_print "Component Version is $COMPONENT_VERSION"

cd ..
fun_print "Current Working Directory is $(pwd)"

#Cloning release_control repository
release_control=$(mktemp -d)
cd "$release_control"
fun_print "Current Working Directory is $(pwd)"
git clone ssh://git@bitbucket.equifax.com:7999/uba/release_control.git
if [ $? -ne 0 ] ; then
	fun_print "ABORTING. Could not clone the component"
	exit 1
fi

#Now update the project version in the release control
cd "$release_control"/release_control

fun_print "Current Working Directory is $(pwd)"
 
git pull origin
if [ $? -ne 0 ] ; then
	fun_print "ABORTING. Could not pull from origin"
	exit 1
fi

git checkout master
if [ $? -ne 0 ] ; then
	fun_print "ABORTING. Could not checkout master branch"
	exit 1
fi

fun_print "Current Working Directory is $(pwd)"

cd "$applicationName"
fun_print "Current Working Directory is $(pwd)"

if [ ! -d "$environment" ]; then
  mkdir -p "$environment"
  if [ $? -ne 0 ] ; then
  	fun_print "ABORTING. Error in creating directory " $environment
  	exit 1
  fi
fi

cd "$environment"
fun_print "Current Working Directory is $(pwd)"

if [ ! -f "app_version" ]; then
	fun_print "File does not exists, so creating app_version file"
	touch app_version
else
	fun_print "File found."
	cat /dev/null > app_version
	echo ${COMPONENT_VERSION} >app_version
fi

fun_print "Adding files to git"

git add --all
message="Commited New version ${COMPONENT_VERSION} of $applicationName"

fun_print "Commit message is : $message"

git commit -m "$message"
if [ $? -ne 0 ] ; then
	fun_print "ABORTING. Error in commiting changes"
	exit 1
fi

git push origin master
if [ $? -ne 0 ] ; then
	fun_print "ABORTING. Error in Pushing changes to the branch master"
	exit 1
fi

#Remove the release control directory
rm -rf "$release_control"

# All completed!
fun_print "---------------------------------------------------------------------------------------------"
fun_print "$0 Completed"

exit 0