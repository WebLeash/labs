#!/bin/env python

import argparse
import os
import sys
import json

from apigeeUtils import ApigeeUtils
from helpers     import *
from nexus_get_artifact import getNexusAuth, getArtifact

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Standard deploy for UK apigee Applications.')
parser.add_argument('-w', '--workspace',      default=workDir)
parser.add_argument('-a', '--approot',        default='')
parser.add_argument('-O', '--apigee-org',     default='efxeu-nonprod')
parser.add_argument('-E', '--apigee-env',     default='qa')
parser.add_argument('-P', '--apigee-proxy',   default='')
parser.add_argument('-D', '--deploy',         default=False, type=str2bool)
parser.add_argument('-v', '--version',        default='')

options = vars(parser.parse_args())

dctVariables = {
    "PROXY_USER":        "webProxyUser",
    "PROXY_PASSWORD":    "webProxyPass",
    "APIGEE_USER":       "apigeeUser",
    "APIGEE_PASSWORD":   "apigeePass",
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"
}

envVars    = getEnvironmentVars(dctVariables)
commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard deploy for UK apigee Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    apigee organisation name .. {0[apigee_org]}
    apigee environment name ... {0[apigee_env]}
    apigee proxy name ......... {0[apigee_proxy]}
    deploy operation .......... {0[deploy]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

proxyURL = buildProxyURL(commonVars['apigee_proxy_host'], 
            envVars['webProxyUser'], envVars['webProxyPass'])

workEnv['HTTP_PROXY']  = proxyURL
workEnv['HTTPS_PROXY'] = proxyURL

################################################################################
# Initialize apigeeUtils

objApigee = ApigeeUtils()
objApigee.webProxies = { 'http': proxyURL, 'https': proxyURL }
objApigee.organisation = options['apigee_org']
objApigee.setAuth(envVars['apigeeUser'], envVars['apigeePass'])

apigeeOrg   = options['apigee_org']
apigeeEnv   = options['apigee_env']
apigeeProxy = options['apigee_proxy']

stateFile = '{0}.state'.format(apigeeOrg)

################################################################################
# Download proxy bundle from Nexus if we're deploying

if(options['deploy']):
    nexusAuth = getNexusAuth(envVars['nexusUser'], envVars['nexusPass'])
    coords    = { 'g': '', 'a': apigeeProxy, 'v': options['version'] }

    if(getArtifact('', coords, 'zip', nexusAuth) != 0):
        exit(1)

    bundleZip = '{0[a]}-{0[v]}.zip'.format(coords)

# Find proxy on apigee and get the currently deployed revision (if applicable)

print('\nRetrieving currently deployed Proxy revision')

currentRev = objApigee.findProxyRevision(apigeeEnv, apigeeProxy)

# Sanity checks

if(currentRev is None):
    print('Failed to retrieve list of proxies - exiting')
    sys.exit(1)

if(isinstance(currentRev, list)):
    print("Multiple versions deployed ({0}) - requires manual intervention".format(currentRev))
    sys.exit(1)

# Is this a deploy or promote

if(options['deploy']):
    # Check if this is a new or existing proxy

    if(currentRev == -1):
        print('Proxy has not been deployed before in this organisation')
        proxyState = { 'newProxy': True,
                       'previousRevision': { apigeeEnv: 0 }}
    else:
        print('Proxy revision {0} currently deployed'.format(currentRev))
        proxyState = { 'newProxy': False,
                       'previousRevision': { apigeeEnv: currentRev }}

    # Import the new revision

    print('\nImporting proxy bundle')

    targetRevision = objApigee.importApi(apigeeProxy, bundleZip)

    if(targetRevision is None):
        print('Failed to import the proxy - exiting')
        sys.exit(1)

    proxyState['targetRevision'] = targetRevision

    print('Proxy revision {0} created'.format(targetRevision))

else: # Promotion
    # Load the state file to find the target revision
    print('Proxy revision {0} currently deployed'.format(currentRev))

    print('\nLoading existing state for the Organisation')

    try:
        with open(stateFile, 'r') as objFile:
            proxyState = json.load(objFile)
    except Exception as error:
        print('failed to open file:\n\t{0}'.format(error))
        sys.exit(1)

    proxyState['previousRevision'][apigeeEnv] = currentRev

    targetRevision = proxyState['targetRevision']
    print('State loaded successfully')

# Save proxy state to org-deploy.state

with open(stateFile, 'w') as objFile:
    json.dump(proxyState, objFile)

# Deploy the new revision into the environment

if(currentRev > 0):
    print('\nUndeploying previous revision')

    objResp = objApigee.undeployRevision(apigeeEnv, apigeeProxy, currentRev)

    if(objResp is None):
        print('Failed to undeploy existing revision - exiting')
        sys.exit(1)

    print('Undeployed successfully')

print('\nDeploying proxy revision {0}'.format(targetRevision))

objResp = objApigee.deployApiRevision(apigeeEnv, apigeeProxy, targetRevision)

if(objResp is None):
    print('Failed to deploy the new revision - exiting')
    sys.exit(1)

print('Deployed successfully')
sys.exit(0)
