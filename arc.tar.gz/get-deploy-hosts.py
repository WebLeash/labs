#!/bin/env python

import argparse
import os
import requests
import json

workDir = os.getcwd()
urlBase = "https://dashboard.devtools.ntg.equifax.com/mrsg/api"

def usage():
    return '''{0} options

GoCD Deploy Hosts fetch script.

ENV VARS:

 GO_PIPELINE_NAME  Mandatory.  The GoCD pipeline name.
 GO_PIPELINE_LABEL Mandatory.  The GoCD pipeline version.

OPTIONS:

  -e     Environment
  -h     Display this help.
    '''.format(os.path.basename(__file__))

parser  = argparse.ArgumentParser(usage=usage())
parser.add_argument('-e', '--environment', required=True)
options = vars(parser.parse_args())

# Check the environment variables are set
pipelineName  = os.environ.get('GO_PIPELINE_NAME')
pipelineLabel = os.environ.get('GO_PIPELINE_LABEL')

strOut = '''\n
    GoCD Deploy Hosts fetch script.

    Running from {0} with options.

    Pipeline name ............. {1}
    Pipeline label ............ {2}
    Environment name .......... {3}
\n'''.format(workDir, pipelineName, pipelineLabel, options['environment'])
print(strOut)

if(pipelineName == None or pipelineLabel == None):
    print('\n==== ABORTING ===== \n\nGoCD Environment variables are not set. This script expects to be run as part of a GoCD job.')
    exit(1)

urlPath = "{0}/gocd/pipelines/{1}".format(urlBase, pipelineName)

print("Looking up system name from {0}".format(urlPath))
    
respPipeline = requests.get(urlPath)
respPipeline.raise_for_status()

jsonPipeline = respPipeline.json()
systemName   = jsonPipeline['system_name']

print('\nSystem name found was ......... {0}'.format(systemName))

urlPath = "{0}/systems/{1}/hosts".format(urlBase, systemName)

print("\nLooking up system hosts from {0}".format(urlPath))

respHosts = requests.get(urlPath)
respHosts.raise_for_status()

targetHosts = []
targetEnv   = options['environment'].upper()

for entry in respHosts.json():
    if(entry['environment'] == targetEnv):
        targetHosts.append(entry['hostname'])

print("\nEnvironment hosts found were .. {0}".format(targetHosts))

with open("targets.txt", "w") as outFile:
    for host in targetHosts:
        outFile.write("{0}\n".format(host))
