#!/usr/bin/env bash

workspace=$(pwd)

: "${GO_PIPELINE_LABEL:=DEFAULT_VALUE}"
: "${GO_PIPELINE_NAME:=DEFAULT_VALUE}"

dashboard="https://dashboard.devtools.ntg.equifax.com/mrsg"

usage()
{
cat << EOF
usage: $0 options

Release Readiness script.

ENV VARS:

 GO_PIPELINE_NAME  Mandatory.  The GoCD pipeline name.
 GO_PIPELINE_LABEL Mandatory.  The GoCD pipeline version.

OPTIONS:

  -h     Display this help.

EOF
}

# Get the parameters
while getopts h option; do
    case "$option" in
        h) usage
           exit 1;;
        ?) usage
           exit 1;;
    esac
done

cat << EOF

    Release Readiness script.

    Running from ${workspace} with options.

    Pipeline name ............. ${GO_PIPELINE_NAME}
    Pipeline version .......... ${GO_PIPELINE_LABEL}

EOF

cd "${workspace}"

if [ "${GO_PIPELINE_NAME}" = "DEFAULT_VALUE" -o "${GO_PIPELINE_LABEL}" = "DEFAULT_VALUE" ] ; then
    echo "ABORTING. Environment variables have not been configured correctly. While this script will run standalone, it is expecting Environment Variables provides from the GoCD runtime."
    exit 1
fi

# Obtain the System Name from the Dashboard API.

url="${dashboard}/api/gocd/pipelines/${GO_PIPELINE_NAME}"

echo "Looking up system name from $url"

json_response="$(curl --silent --noproxy """*""" --header """Accept: application/json""" """$url""")"

system_name=$(jq -r '.system_name' <<< "${json_response}")

if [ "${system_name}" = "null" ] ; then
    echo -e "\nABORTING. System could not be found. Work with the EU Systems Team to ensure this application is included in the CMDB."
    exit 1
fi

echo -e "\n    System name found was ..... ${system_name}"

url="${dashboard}/api/systems/${system_name}/applications?q=${GO_PIPELINE_LABEL}"

echo -e "\nLooking up the build from $url"

json_response="$(curl --silent --noproxy """*""" --header """Accept: application/json""" """$url""")"

app_id=$(jq -r '.appid' <<< "${json_response}")
build_version=$(jq -r '.version' <<< "${json_response}")

if [ "${app_id}" = "null" ] ; then
    echo -e "\nABORTING. No application build can be found for this System and Version number."
    exit 1
fi

echo -e "\n    Build app id found was .... ${app_id}"
echo -e "    Build version found was ... ${build_version}"

url="${dashboard}/api/applications/${app_id}/dependencies"

echo -e "\nLooking up the dependencies from $url"

json_response="$(curl --silent --noproxy """*""" --header """Accept: application/json""" """$url""")"

echo -e "\n    Dependencies found in the build."

jq -r '.[] | [.depid,.depGroupId,.depArtifactId,.depVersion] | @tsv' <<< "${json_response}" > ${workspace}/dependencies.txt

snapshot=0
while read -r depid depGroupId depArtifactId depVersion ; do
    echo "        #${depid} ${depGroupId}:${depArtifactId}:${depVersion}"
    if [[ ${depVersion} == *SNAPSHOT* ]] ; then
        snapshot=1
    fi
done < "${workspace}/dependencies.txt"

rm -f "${workspace}/dependencies.txt"

if [ ${snapshot} -eq 0 ] ; then
    echo -e "\nNo SNAPSHOT dependencies found in this build.  Good!"
else
    echo -e "\nABORTING. This build contains a SNAPSHOT dependency.  The SNAPSHOT needs to be removed before this build can be progressed further and deployed."
    exit 1
fi

exit 0;
