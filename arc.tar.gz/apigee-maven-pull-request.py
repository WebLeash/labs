#!/bin/env python

import argparse
import os
from buildRunner import cmdRunner
from helpers     import *

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

def usage():
    return '''usage: {0} options

Standard Apigee Checks for Pull Requests for UK Deployments.

ENV VARS:

 PROJECT           Mandatory.  Sonar plugin. The Bitbucket project.
 REPOSITORY        Mandatory.  Sonar plugin. The Bitbucket repository.
 PR_NAME_ID        Mandatory.  Sonar plugin. The ENV VAR containing the ID for the PR.
 GIT_PASSWORD      Mandatory.  Sonar plugin. The password for publishing issue list to Bitbucket.
                                             (SonarQube holds the username).

OPTIONS:
  -w               Optional. Workspace.  Defaults to script directory.
  -U [true|false]  Optional. Update the parent version?  Defaults to true.
  -P [true|false]  Optional. Update the property versions?  Defaults to true.
  -N [true|false]  Optional. Set up the NPM environment to use Nexus 3. Defaults to false.
  -n [NPM dir]     Optional. If using Nexus 3, provide the root directory for the .npmrc file
    '''.format(os.path.basename(__file__))

parser  = argparse.ArgumentParser(usage=usage())
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-U', '--update-parent',     default=True, type=str2bool)
parser.add_argument('-P', '--update-property',   default=True, type=str2bool)
parser.add_argument('-N', '--use-nexus3-npm',    default=False, type=str2bool)
parser.add_argument('-n', '--npm-root-dir',      default='')
options = vars(parser.parse_args())

commonVars = getCommonVars()

dctVariables = {
    "PROJECT":         "project",
    "REPOSITORY":      "repository",
    "PR_NAME_ID":      "prNameId",
    "GIT_PASSWORD":    "gitPassword",
    "NEXUS3_USERNAME": "nexusUser",
    "NEXUS3_PASSWORD": "nexusPass"}

envVars = getEnvironmentVars(dctVariables)

# Expand PRNameId

if(envVars['prNameId'] in os.environ):
    envVars['prNameId'] = os.environ.get(envVars['prNameId'])

################################################################################
# Headline summary output

strOut = '''\n
    Standard Apigee Checks for Pull Requests for UK Deployments.

    Running from {0[workspace]} with options.

    Update parent version ..... {0[update_parent]}
    Update property versions .. {0[update_property]}
    NPM use Nexus 3 repository  {0[use_nexus3_npm]}
    NPM root directory ........ {0[npm_root_dir]}

    Environment variables.

    Bitbucket project ......... {1[project]}
    Bitbucket repository ...... {1[repository]}
    Bitbucket PR Number ....... {1[prNameId]}
\n'''.format(options, envVars)
print(strOut)

workDir = options['workspace']

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

cmdOpts = ''

# Use Nexus 3 as the NPM repository if selected

if(options['use_nexus3_npm']):
    # Build an .npmrc file for the project
    npmRootDir = os.path.join(approot, options['npm_root_dir'])
    npmRepo    = '{0[nexus_base_url]}/{0[nexus_npm_proxy]}\n'.format(commonVars)

    buildNpmrc(envVars['nexusUser'], envVars['nexusPass'], npmRootDir, npmRepo)

    # Set maven options
    cmdOpts += ' -Dfrontend.npm.npmInheritsProxyConfigFromMaven=false'

################################################################################

# Update the parent pom version

if(options['update_parent']):
    cmdRunner(workDir, workEnv, 'mvn -e -U -B versions:update-parent')

# Update properties to the latest version of dependencies

if(options['update_property']):
    cmdRunner(workDir, workEnv, 'mvn -e -U -B versions:update-properties')

# Install Node / NPM and run Istanbul to produce code coverage report

cmdRunner(workDir, workEnv, 'mvn -e test -Dswagger.exec.skip=true' + cmdOpts)

# Run SonarQube testing

cmdLine = 'mvn -e org.sonarsource.scanner.maven:sonar-maven-plugin:{0}:sonar ' \
        '-Dsonar.buildbreaker.skip=true ' \
        '-Dsonar.javascript.lcov.reportPaths=coverage/lcov.info ' \
        '-Dsonar.analysis.mode="preview" -Dsonar.stash.notification ' \
        '-Dsonar.stash.project="{1[project]}" ' \
        '-Dsonar.stash.repository="{1[repository]}" ' \
        '-Dsonar.stash.pullrequest.id="{1[prNameId]}" ' \
        '-Dsonar.stash.password="{1[gitPassword]}"'
cmdLine = cmdLine.format(commonVars['sonar_version'], envVars)

cmdRunner(workDir, workEnv, cmdLine, 'SonarQube Scan')
