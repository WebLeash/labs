#!/usr/bin/env bash

workspace=$(pwd)

: "${HPFOD_USERNAME:=DEFAULT_VALUE}"
: "${HPFOD_PASSWORD:=DEFAULT_VALUE}"
: "${PROXY_USER:=DEFAULT_VALUE}"
: "${PROXY_PASSWORD:=DEFAULT_VALUE}"
: "${GO_PIPELINE_LABEL:=DEFAULT_VALUE}"

package_name=""
package_version="RELEASE"
package_type="jar"
package_repository="uk-releases"
package_group=""
package_artifact=""
fod_bsi_token=""
source_code_repository=""
source_only="false"
repackage_as_zip="false"

usage()
{
cat << EOF
usage: $0 options

Upload artifact to HP FOD.

ENV VARS:

 HPFOD_USERNAME    Mandatory.  FOD credentials.
 HPFOD_PASSWORD    Mandatory.  FOD credentials.
 PROXY_USER        Mandatory.  Proxy credentials.
 PROXY_PASSWORD    Mandatory.  Proxy credentials.
 GO_PIPELINE_LABEL Mandatory.  The GoCD pipeline details.

OPTIONS:
  -n               Mandatory. Package Name.
  -v               Mandatory. Package version.  Defaults to "RELEASE".
  -t [jar|war|ear] Mandatory. Package type.  Defaults to "jar".
  -r               Mandatory. Package repository.  Defaults to "uk-releases".
  -g               Mandatory. Package group id.
  -a               Mandatory. Package artifact id.
  -b               Mandatory. FOD BSI Token.
  -s               Mandatory. Source code repository.
  -S [true|false]  Optional.  Upload Source Only?  Defaults to false.
  -Z [true|false]  Optional.  Repackage artifact as a zip.  Defaults to false.

EOF
}

# Get the parameters
while getopts n:v:t:r:g:a:b:s:S:Z: option; do
    case "$option" in
        n) package_name=$OPTARG;;
        v) package_version=$OPTARG;;
        t) package_type=$OPTARG;;
        r) package_repository=$OPTARG;;
        g) package_group=$OPTARG;;
        a) package_artifact=$OPTARG;;
        b) fod_bsi_token=$OPTARG;;
        s) source_code_repository=$OPTARG;;
        S) source_only=$OPTARG;;
        Z) repackage_as_zip=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

if [ -z "${package_name}" -o -z "${package_version}" -o -z "${package_type}" \
     -o -z "${package_repository}" -o -z "${package_group}" -o -z "${package_artifact}" \
     -o -z "${fod_bsi_token}" -o -z "${source_code_repository}" ] ; then
    usage
    exit 1
fi

if [ "${source_only}" = "true" ] ; then
    source_only="true"
else
    source_only="false"
fi

if [ "${repackage_as_zip}" = "true" ] ; then
    repackage_as_zip="true"
else
    repackage_as_zip="false"
fi

cat << EOF

    Upload artifact to HP FOD.

    GoCD label ....... ${GO_PIPELINE_LABEL}

    Package name ..... ${package_name}
    Package version .. ${package_version}
    Package type ..... ${package_type}
    Package repository ${package_repository}
    Package group .... ${package_group}
    Package artifact . ${package_artifact}

    FOD BSI Token .... ${fod_bsi_token}

    Source Code ...... ${source_code_repository}
    Source Code Only . ${source_only}
    Repackage ........ ${repackage_as_zip}

EOF

cd "${workspace}"

echo "Running from ${workspace}"

echo "Tidying up current directory".

ls -la

rm -f *.zip
rm -rf source-code/*

ls -la

# Download the source code.

echo "Cloning source code repository"

count=0
for repo in $(echo $source_code_repository | tr "|" " "); do
 
	echo "$repo"
    
	git clone "ssh://git@bitbucket.equifax.com:7999/${repo}.git" source-code-${count}
	cd source-code-${count}
		if [ $count -eq 0 ]; then
           git archive -o ../source-code-${count}.zip `echo "${GO_PIPELINE_LABEL}" | cut -d- -f2`
		else
           git archive -o ../source-code-${count}.zip HEAD
		fi
	cd ..
	
	echo "Remove test directories and non-source code from the zip file"
	zip -d source-code-${count}.zip "**/src/test/*" "/src/test/*" "**/*.csv" "**/*.pdf" "pom.xml" "**/pom.xml" "**/standalone/*" "/standalone/*" "**/standalone_new/*" "/standalone_new/*" "**/*.sql" "**/*.proc" "**/*.prc" "**/*xbeans/*" "**/*xmlbeans/*" "**/bom/*" "**/rules/*" "**/*.ksh" "**/*BATCH/*" "/*BATCH/*" "**/*batch/*" "/*batch/*" "**/*config/*" "**/*models/*" "/*.bat" "**/*.bat" "**/*.xmi"
	echo "List contents of zip file"
    unzip -vl source-code-${count}
	echo "Remove source code directory"
	rm -rf source-code**/*
	count=$((count+1));

done

zip source-code.zip source-code-*.zip

# Download the binary file.  (unless we're only doing source code).

binary_filename=""

if [ "${source_only}" = "false" ] ; then

    binary_filename="${package_artifact}-${package_version}.${package_type}"

    ~/build-scripts/nexus_get_artifact.py -r ${package_repository} -g ${package_group} -n ${package_name} -v ${package_version} -t ${package_type}

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Could not download binary file"
        exit 1
    fi

    if [ "${repackage_as_zip}" = "true" ] ; then

        echo "Repackaging ${binary_filename}"

        mkdir -p extracted-binary

        unzip "${binary_filename}" -d extracted-binary

        zip -r "extracted-binary.zip" extracted-binary

        rm "${binary_filename}"

        rm -rf extracted-binary/*

        binary_filename="extracted-binary.zip"

    fi

fi

# Package it all back up again.

cd "${workspace}"

if [ "${source_only}" = "true" ] ; then
    # Rename the source code file as the upload file.
    mv source-code.zip file_to_upload.zip
else
    # Create a zip containing source code and binary together.
    zip -r file_to_upload.zip source-code.zip "${binary_filename}"
    rm "${binary_filename}"
    rm source-code.zip
fi

echo "List contents of zip file"

unzip -vl file_to_upload.zip

#Cleaning up the source files
rm -rf source-code-*
java -Dhttps.protocols="TLSv1.2" -Djdk.tls.client.protocols="TLSv1.2" -jar "/var/go/FodUpload_3.0.8.jar" \
     -scanPreferenceId "1" -entitlementPreference "2" \
     -userCredentials "${HPFOD_USERNAME}" "${HPFOD_PASSWORD}" \
     -bsiToken "${fod_bsi_token}" -zipLocation "file_to_upload.zip" \
     -proxy "http://172.18.100.15:18717" "${PROXY_USER}" "${PROXY_PASSWORD}"

if [ $? -ne 0 ] ; then
    echo "ABORTING. Upload to Fortify has failed."
    exit 1
fi

rm file_to_upload.zip

exit 0;
