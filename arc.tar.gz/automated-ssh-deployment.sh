#!/usr/bin/env bash

: "${GO_PIPELINE_LABEL:=DEFAULT_VALUE}"

workspace=$(pwd)
deployment_hosts="${workspace}/deployment-hosts"

application_rpm_name=""
environment_name=""
service_name=""
region=""
environment_profile_path=""
is_legacy="N"
config_rpm_name=""
haproxy_1=""
haproxy_2=""
hostname_1=""
hostname_2=""
tomcat_runtime_path=""
is_batch="N"
is_tomcat="N"
deployment_hosts_repo=""
user_name="appmgr"
rpm_releases_repo="uk-rpm-releases"
liquibase_profile_path=""


usage()
{
cat << EOF
usage: $0 options

SSH Deployment wrapper script.
This is a wrapper script - validation occurs in installApplication.sh (arguments align).

ENV VARS:

 GO_PIPELINE_LABEL                                 : the app version number being installed.

OPTIONS:

  -a : App RPM Name                                : (e.g. sf-xmlcpulink-packaging )
  -s : Service Name (optional)                     : (e.g. xmlcpulink_tc )
  -l : Is it a legacy application deployment?      : (e.g. Y/N)
  -u : Username                         		   : (e.g. appmgr|spdmgr)
  -R : RPM repo                                    : (e.g. uk-rpm-release|sp-rpm-releases)

  Need these parameters when isLegacy is N

  -e : Environment                                 : (e.g. acceptance )
  -r : Region (required for prod environment)      : (e.g. <blue|green> )
  -p : Environment Properties File Path(optional)  : (e.g. /opt/esg/config/profile.properties)
  -d : Deploy Hosts Repository                     : (e.g. ssh://git@bitbucket.equifax.com:7999/ukesg/ukesg-stoppress-deployment-scripts.git)
  -L : Liquibase Profile Path(optional)            : (e.g. /opt/esg/config/esg-insurance.properties)

  Need these parameters when isLegacy is Y

  -c : Config RPM name                             : (e.g. sf-xmlcpulink-config-packaging)
  -h : HAProxy server 1 (backend/servername)       : (e.g. xmlcpulink/hostname_1)
  -b : HAProxy server 2 (backend/servername)       : (e.g. xmlcpulink/hostname_2)
  -f : Server 1                                    : (e.g. uwfd1lc9a001.app.c9.equifax.com)
  -t : Server 2                                    : (e.g. udlt1lc9a001.app.c9.equifax.com)
  -w : Is it a batch implementation?               : (e.g. Y/N, Y if haproxy is not used)
  -x : Is tomcat?                                  : (e.g. Y/N, Y if the deployment server is tomcat)

  Need these parameters when Tomcat is Y

  -n : tomcat runtime name                         : (e.g. /opt/tomcat-runtimes/xmlcpulink)

EOF
}

# Get the parameters
while getopts a:e:s:r:p:l:c:h:b:f:t:n:w:x:d:u:R:L: option; do
    case "$option" in
	    a) application_rpm_name=$OPTARG;;
	    e) environment_name=$OPTARG;;
	    s) service_name=$OPTARG;;
	    r) region=$OPTARG;;
	    p) environment_profile_path=$OPTARG;;
	    l) is_legacy=$OPTARG;;
	    c) config_rpm_name=$OPTARG;;
	    h) haproxy_1=$OPTARG;;
	    b) haproxy_2=$OPTARG;;
	    f) hostname_1=$OPTARG;;
	    t) hostname_2=$OPTARG;;
	    n) tomcat_runtime_path=$OPTARG;;
	    w) is_batch=$OPTARG;;
	    x) is_tomcat=$OPTARG;;
	    d) deployment_hosts_repo=$OPTARG;;
	    u) user_name=$OPTARG;;
		R) rpm_releases_repo=$OPTARG;;
		L) liquibase_profile_path=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

cat << EOF

    Standard Maven build for Pull Requests for UK Applications.

    Running from ${workspace} with options.

    App RPM Name ..................... ${application_rpm_name}
    RPM Release Repo Name ............ ${rpm_releases_repo}
    Environment Name ................. ${environment_name}
    Service Name ..................... ${service_name}
    Region ........................... ${region}
    Env Profile Path ................. ${environment_profile_path}
    Liquibase Profile Path ........... ${liquibase_profile_path}

    Legacy application ............... ${is_legacy}

    Config RPM ....................... ${config_rpm_name}
    HAProxy 1 ........................ ${haproxy_1}
    HAProxy 2 ........................ ${haproxy_2}
    Hostname 1 ....................... ${hostname_1}
    Hostname 2 ....................... ${hostname_2}

    Hosts Repository ..................${deployment_hosts_repo}

    Is Tomcat application .............${is_tomcat}
    Tomcat Runtime ................... ${tomcat_runtime_path}

    Is Batch application ............. ${is_batch}
    Username ......................... ${user_name}

    Environment variables.

    App Version ....................... ${GO_PIPELINE_LABEL}

EOF

if [ ! -d "${deployment_hosts}" ] ; then
    mkdir "${deployment_hosts}"
fi

if [ ! -z "${deployment_hosts_repo}" ] ; then
    git clone "${deployment_hosts_repo}" "${deployment_hosts}"
fi

cd "${deployment_hosts}"

command="~/build-scripts/installApplication.sh -a \"${application_rpm_name}\" -v \"$GO_PIPELINE_LABEL\" -s \"${service_name}\" -e \"${environment_name}\" -r \"${region}\" -u \"${user_name}\" -R \"${rpm_releases_repo}\" -p \"${environment_profile_path}\""

if [ "${liquibase_profile_path}" != "" ] ; then
        command="${command} -L \"${liquibase_profile_path}\""
fi

if [ "${is_legacy}" = "Y" ] ; then

    command="${command} -l \"${is_legacy}\" -c \"${config_rpm_name}\" -f \"${hostname_1}\""

    if [ "${hostname_2}" != "" ] ; then
        if [ "${is_batch}" = "Y" ] ; then
            command="${command} -t \"${hostname_2}\""
        else
            command="${command} -b \"${haproxy_2}\" -t \"${hostname_2}\""
        fi
    fi

    if [ "${is_batch}" = "Y" ] ; then
        command="${command} -w \"${is_batch}\""
    else
        command="${command} -h \"${haproxy_1}\""
    fi

    if [ "${is_tomcat}" = "Y" ] ; then
        command="${command} -n \"${tomcat_runtime_path}\" -x \"${is_tomcat}\""
    fi

fi

echo "${command}"

eval "${command}"

if [ $? -ne 0 ] ; then
    echo "ABORTING. Installation failed."
    exit 1
fi

exit 0;
