#!/usr/bin/env bash

# Make the cwd that of this script
cd "$(dirname "$0")"

workspace=$(pwd)

# The DOT Directory for building the Dependency Tree information.  This is typically
# a subdirectory, e.g. that of the war, but not the parent.
dot_dir=""
# The Subdirectory holding the application root - typically this is the current dir
# but may sometimes be a subdirectory if the repository is structured.
app_root_dir=""
# Do we deploy to Nexus.
deploy_to_nexus="true"
# When building, do we update the parent pom to the latest version.
update_parent="true"
# When building, do we update versions in properties to the latest version.
update_property_versions="true"
# When building, do we set a new version of the application.
update_application_version="true"
# Do we tag the changes and push back.
tag_changes="true"

# Bluebird integration. Used to maintain Release Control coordinates.
bb_update_release_control="false"
# Bluebird integration. The Name of the application.
bb_app_name=""

# Do we perform pit mutation testing.
enable_pit_testing="false"
# At what % mutation threshold will be break the build.  0-100, where 0 means do not break the build.
pit_mutation_threshold="70"

source common-variables.sh

usage()
{
cat << EOF
usage: $0 options

Standard Maven build for UK Applications.

OPTIONS:
  -w               Optional. Workspace.  Defaults to script directory.
  -d               Optional. DOT directory.  Defaults to current dir.
  -a               Optional. App root directory.  Defaults to current dir.
  -D [true|false]  Optional. Deploy to Nexus?  Defaults to true.
  -U [true|false]  Optional. Update the parent version?  Defaults to true.
  -P [true|false]  Optional. Update the property versions?  Defaults to true.
  -A [true|false]  Optional. Update the application version?  Defaults to true.
  -T [true|false]  Optional. Tag the change back to the repo.  Defaults to true.
  -B [true|false]  Optional. Bluebird.  Update bluebird release controls.  Defaults to false.
  -b               Optional. Bluebird.  Application name.
  -m [0-100]       Optional. PIT Mutation Threshold.  Value 0-100.
  -M [true|false]  optional. Enable PIT testing?  Defaults to false.
EOF
}

# Get the parameters
while getopts w:d:a:D:U:P:A:T:B:b:M:m: option; do
    case "$option" in
        w) workspace=$OPTARG;;
        d) dot_dir=$OPTARG;;
        a) app_root_dir=$OPTARG;;
        D) deploy_to_nexus=$OPTARG;;
        U) update_parent=$OPTARG;;
        P) update_property_versions=$OPTARG;;
        A) update_application_version=$OPTARG;;
        T) tag_changes=$OPTARG;;
        B) bb_update_release_control=$OPTARG;;
        b) bb_app_name=$OPTARG;;
        m) pit_mutation_threshold=$OPTARG;;
        M) enable_pit_testing=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

if [ -z "$dot_dir" ] ; then
    dot_dir="${workspace}"
else
    dot_dir="${workspace}"/"${dot_dir}"
fi

if [ -z "$app_root_dir" ] ; then
    app_root_dir="${workspace}"
else
    app_root_dir="${workspace}"/"${app_root_dir}"
fi

if [ "${deploy_to_nexus}" = "deploy" -o "${deploy_to_nexus}" = "true" ] ; then
    deploy_to_nexus="true"
else
    deploy_to_nexus="false"
fi

if [ "${update_parent}" = "true" ] ; then
    update_parent="true"
else
    update_parent="false"
fi

if [ "${update_property_versions}" = "true" ] ; then
    update_property_versions="true"
else
    update_property_versions="false"
fi

if [ "${update_application_version}" = "true" ] ; then
    update_application_version="true"
else
    update_application_version="false"
fi

if [ "${tag_changes}" = "true" ] ; then
    tag_changes="true"
else
    tag_changes="false"
fi

if [ "${bb_update_release_control}" = "true" ] ; then
    bb_update_release_control="true"
else
    bb_update_release_control="false"
fi

if [ "${enable_pit_testing}" = "true" ] ; then
    enable_pit_testing="true"
else
    enable_pit_testing="false"
fi

cat << EOF

    Standard Maven build for UK Applications.

    Running from ${workspace} with options.

    DOT Directory ............. ${dot_dir}
    App root directory ........ ${app_root_dir}
    Deploy to Nexus ........... ${deploy_to_nexus}
    Update parent version ..... ${update_parent}
    Update property versions .. ${update_property_versions}
    Update application version  ${update_application_version}
    Tag changes ............... ${tag_changes}
    BB - Release Control ...... ${bb_update_release_control}
    BB - Application name ..... ${bb_app_name}
    Enable PIT Mutation Tests . ${enable_pit_testing}
    PIT Mutation Threshold % .. ${pit_mutation_threshold}

EOF

cd "${app_root_dir}"

# Update the parent pom version

if [ "${update_parent}" = "true" ] ; then

    mvn -e -U -B versions:update-parent

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-parent goal."
        exit 1
    fi

fi

# Update properties to the latest version of dependencies

if [ "${update_property_versions}" = "true" ] ; then

    mvn -e -U -B versions:update-properties

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-properties goal."
        exit 1
    fi

fi

# Update the main application version

if [ "${update_application_version}" = "true" ] ; then

    mvn -e versions:set

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run version:set goal."
        exit 1
    fi

fi

# Build the application and run code coverage tools using Clover.
# Requires Java 1.8.0

export JAVA_HOME="/usr/lib/jvm/java-1.8.0"

mvn -e clean org.openclover:clover-maven-plugin:${clover_version}:setup verify org.openclover:clover-maven-plugin:${clover_version}:aggregate org.openclover:clover-maven-plugin:${clover_version}:clover

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not build the application."
    exit 1
fi

if [ "${enable_pit_testing}" = "true" ] ; then
    # Run PIT Tests. Moved to start to allow the results to be picked up by SonarQube.
    # Unlike in the PR build this is full-project rather than based on source control changes.

    mvn -e org.pitest:pitest-maven:1.4.0:mutationCoverage -DoutputFormats=XML,HTML -DmutationThreshold=${pit_mutation_threshold}

    if [ $? -ne 0 ] ; then
        echo "ABORTING. PIT testing failed."
        exit 1
    fi
fi

# Don't worry about "skip tests" - we have proven that tests run cleanly in the previous stage.

mvn -e install -Dmaven.test.skip=true

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not build the application."
    exit 1
fi

mvn -e org.sonarsource.scanner.maven:sonar-maven-plugin:${sonar_version}:sonar -Dsonar.clover.reportPath=target/site/clover/clover.xml

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not run the SonarQube integration."
    exit 1
fi

# Deploy to Nexus.

if [ "${deploy_to_nexus}" = "true" ]; then

    # Force to use Maven 3.3.9 due to Nexus having proxy that doesn't like Maven 3.5.x

    temp_m2_home="${M2_HOME}"
    temp_maven_home="${MAVEN_HOME}"

    export M2_HOME="/usr/share/maven339/apache-maven-3.3.9"
    export MAVEN_HOME="/usr/share/maven339/apache-maven-3.3.9"

    mvn339 -e clean deploy -Dmaven.test.skip=true

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Could not deploy to Nexus."
        exit 1
    fi

    # Put them back again.

    export M2_HOME="${temp_m2_home}"
    export MAVEN_HOME="${temp_maven_home}"

fi

# Tag changes using the tag-changes.sh script.

if [ "${tag_changes}" = "true" ] ; then
    ~/build-scripts/tag-changes.sh "${app_root_dir}"
fi

# Run Dependency checker in the subdirectory for the DOT processing.

cd "${dot_dir}"

mvn -e org.apache.maven.plugins:maven-dependency-plugin:3.1.0:tree -DoutputType="dot" -DoutputFile="/var/go/dot/\${project.build.finalName}.dot"

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not run Dependency Tree on the application."
    exit 1
fi

# Update BB release controls

cd "${app_root_dir}"

if [ "${bb_update_release_control}" = "true" ] ; then

    ~/build-scripts/release-control-version-update.sh -r "${app_root_dir}" -e "int" -a "${bb_app_name}"

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Could not update BB release controls."
        exit 1
    fi

fi

# Tidy up.

mvn -e versions:revert

mvn -e clean

exit 0;
