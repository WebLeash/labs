#!/bin/env python

import requests

from requests.auth import HTTPBasicAuth
from nexus3Search  import nexus3Search
from helpers       import *

commonVars = getCommonVars()
nexus3Host = commonVars['nexus_host']

searchURL2 = 'http://repo.devcentral.equifax.com/nexus/service/local/artifact/maven'

################################################################################

def downloadFromNexus(reqURL, coords, strType, nexusAuth):
    print('Downloading {0[a]} - {0[v]} from:'.format(coords))
    print(' - {0}'.format(reqURL))

    strFile = '{0[a]}-{0[v]}.{1}'.format(coords, strType)
    reqFile = requests.get(reqURL, auth=nexusAuth, stream=True)
    if(reqFile.status_code != 200):
        return -1

    with open(strFile, 'wb') as outFile:
        for chunk in reqFile.iter_content(chunk_size=1024): 
            if chunk: # filter out keep-alive new chunks
                outFile.write(chunk)

    return 0

################################################################################

def downloadNexus3(strRepo, coords, strType, nexusAuth):
    objSearch = nexus3Search(nexus3Host)
    objSearch.basicAuth = nexusAuth

    if(objSearch.searchName(coords['a']) != 0):
        return -1

    if(len(objSearch) < 1):
        return -1

    dctArtifact = objSearch.findVersion(coords['v'], strType)

    if(dctArtifact == None):
        print('ERROR: Unable to find {0[a]} - {0[v]} on Nexus 3'.format(coords))
        print(' - But artifacts for {0[a]} are available'.format(coords))
        exit(1)

    reqURL = 'https://{0}/repository/{1[repository]}/{1[path]}'
    reqURL = reqURL.format(nexus3Host, dctArtifact)

    return downloadFromNexus(reqURL, coords, strType, nexusAuth)

################################################################################

def getArtifact(strRepo, coords, strType, nexusAuth):
    # Query Nexus 3 for artifact first
    result = downloadNexus3(strRepo, coords, strType, nexusAuth)

    # Fall back to Nexus 2 if no artifact found
    if(result == -1):
        reqURL = '{0}/redirect?r={1}&g={2[g]}&a={2[a]}&v={2[v]}&e={3}'
        reqURL = reqURL.format(searchURL2, strRepo, coords, strType)
        result = downloadFromNexus(reqURL, coords, strType, None)

    return result

################################################################################
# Build Auth object (abstraction so the caller doesn't need to import requests)

def getNexusAuth(nexusUser, nexusPass):
    return HTTPBasicAuth(nexusUser, nexusPass)

################################################################################

if __name__ == "__main__":
    import argparse
    import os

    parser  = argparse.ArgumentParser(description='Artifact downloader for UK Applications.')
    parser.add_argument('-r', '--repo',    default='')
    parser.add_argument('-g', '--group',   default='')
    parser.add_argument('-n', '--name',    default='')
    parser.add_argument('-v', '--version', default='')
    parser.add_argument('-t', '--type',    default='')
    options = vars(parser.parse_args())

    dctVariables = {
        "NEXUS3_USERNAME":   "nexusUser",
        "NEXUS3_PASSWORD":   "nexusPass"}

    envVariables = getEnvironmentVars(dctVariables)

    nexusAuth = HTTPBasicAuth(envVariables['nexusUser'], envVariables['nexusPass'])
    coords    = { 'g': options['group'], 'a': options['name'], 'v': options['version'] }

    result    = getArtifact(options['repo'], coords, options['type'], nexusAuth)

    if(result == -1):
        exit(1)
