import os
import base64
import contextlib

from zipfile import ZipFile

################################################################################
# Handle environment variables

def getEnvironmentVars(dctVariables):
    dctEnvironment = {}
    missingVar     = []

    for envKey in dctVariables.keys():
        envValue = os.environ.get(envKey)

        if(envValue is None):
            missingVar.append(envKey)
        else:
            dctEnvironment[dctVariables[envKey]] = envValue

    # If any environment variables are missing, complain then exit
    if(len(missingVar) > 0):
        missingVar.sort()
        strErr = 'Missing environment variables:\n'
        for strVar in missingVar:
            strErr += ' - {0}\n'.format(strVar)
        strErr += '\nExiting.'
        print(strErr)
        exit(1)

    return dctEnvironment

################################################################################
# Read variables from the common-variables.sh file

def getCommonVars():
    scriptDir  = os.path.dirname(os.path.realpath(__file__))
    fileName   = os.path.join(scriptDir, 'common-variables.sh')
    commonVars = {}

    with open(fileName) as objFile:
        for strLine in objFile:
            # Handle comments and non-assignment lines
            if(strLine[:1] == '#'): continue
            if('=' not in strLine): continue

            name, var = strLine.partition("=")[::2]
            commonVars[name.strip()] = var.strip().replace('"', '')

    return commonVars

################################################################################
# build npmrc file

def buildNpmrc(nexusUser, nexusPass, npmRootDir, npmRepoURL):
    npmFile   = os.path.join(npmRootDir, '.npmrc')
    authStr   = '{0}:{1}'.format(nexusUser, nexusPass)
    basicAuth = base64.b64encode(authStr.encode('utf8'))

    with open(npmFile, 'w') as file:
        file.write('always-auth=true\n')
        file.write('_auth={0}\n'.format(basicAuth.decode('utf8')))
        file.write('registry={0}\n'.format(npmRepoURL))

################################################################################
# Build a proxyURL suitable for injection into environment variables

def buildProxyURL(proxyHost, proxyUser, proxyPass):
    # Remote any leading or trailing whitespace
    proxyHost = proxyHost.strip()
    proxyUser = proxyUser.strip()
    proxyPass = proxyPass.strip()

    # Build the auth string if the user name and password are specified
    if(proxyUser != '' and proxyPass != ''):
        proxyAuth = '{0}:{1}@'.format(proxyUser, proxyPass)
    else:
        proxyAuth = ''

    return 'http://{0}{1}/'.format(proxyAuth, proxyHost)

################################################################################
# Output information about zip file contents

def zipInfo(zipFile):
    sizeFileTotal = 0
    sizeCompTotal = 0
    fileCount     = 0

    dctCompression = {
       0: "Stored",   1: "Shrunk",   2: "Reduce1",  3: "Reduce2",  4: "Reduce3",
       5: "Reduce4",  6: "Implode",  7: "Token",    8: "Defl:#",   9: "Def64#",
      10: "ImplDCL", 12: "BZip2",   14: "LZMA",    18: "Terse",   19: "IBMLZ77",
      97: "WavPack", 98: "PPMd" }

    with contextlib.closing(ZipFile(zipFile, 'r')) as objZip:
        print('Archive: {0}'.format(zipFile))
        print(' Length   Method    Size  Cmpr    Date    Time   CRC-32   Name')
        print('--------  ------  ------- ---- ---------- ----- --------  ----')

        for objInfo in objZip.infolist():
            sizeFile  = objInfo.file_size
            sizeComp  = objInfo.compress_size
            dtString  = '{0[2]:02}-{0[1]:02}-{0[0]} {0[3]:02}:{0[4]:02}'
            dtString  = dtString.format(objInfo.date_time)
            strCRC    = objInfo.CRC
            strFile   = objInfo.filename

            # Handle 0 sized entries
            if(sizeFile == 0):
                sizeRatio = 0
            else:
                sizeRatio = 1 - (float(sizeComp) / sizeFile)

            # Map compression types to ids
            strType   = dctCompression.get(objInfo.compress_type, 'Unk:###')

            # Calculate totals
            sizeFileTotal += sizeFile
            sizeCompTotal += sizeComp
            fileCount += 1

            #         Length  Method Size     Cmpr   dt  CRC-32   Name
            strOut = '{0:>8}  {1:7} {2:>7}  {3:3.0%} {4} {5:08X}  {6}'
            strOut = strOut.format(sizeFile, strType, sizeComp, sizeRatio, dtString, strCRC, strFile)
            print(strOut)

    # Output summary
    sizeRatio = 1 - float(sizeCompTotal) / sizeFileTotal

    print('--------          -------  ---                            -------')
    strOut = '{0:>8}          {1:>7}  {2:3.0%}                            {3} files'
    strOut = strOut.format(sizeFileTotal, sizeCompTotal, sizeRatio, fileCount)
    print(strOut)
