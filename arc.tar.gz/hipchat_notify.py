#!/bin/env python

from helpers import *
import argparse, os, json, requests

baseURL = 'https://hipchat.devcentral.equifax.com/v2/room'
gocdURL = 'https://gocd.devtools.ntg.equifax.com/go'

################################################################################
# Option Parser

parser  = argparse.ArgumentParser()
parser.add_argument('-c', '--colour',    default='green')
parser.add_argument('-a', '--authToken', required=True)
parser.add_argument('-r', '--roomId',    default='3089')
parser.add_argument('text', nargs="+")

options = vars(parser.parse_args())

dctVariables = {
    "GO_PIPELINE_NAME":    "pipelineName",
    "GO_PIPELINE_LABEL":   "pipelineLabel",
    "GO_PIPELINE_COUNTER": "pipelineCount",
    "GO_STAGE_NAME":       "stageName",
    "GO_STAGE_COUNTER":    "stageCounter"}

envVariables = getEnvironmentVars(dctVariables)

################################################################################

goLink = '{0}/pipelines/{1[pipelineName]}/{1[pipelineCount]}/{1[stageName]}/{1[stageCounter]}/jobs'
goLink = goLink.format(gocdURL, envVariables)

strText = u' '.join(options['text'])

strOut = '<A HREF="{0}"> {1[pipelineName]} {1[pipelineLabel]} {2}</A>'
strOut = strOut.format(goLink, envVariables, strText)

headers = {'Content-Type': 'application/json'}
msgOut  = {'message_format': 'html',
           'notify': False,
           'color': options['colour'],
           'message': strOut}

################################################################################

url = '{0}/{1}/notification?auth_token={2}'
url = url.format(baseURL, options['roomId'], options['authToken'])

req = requests.post(url, data=json.dumps(msgOut), headers=headers)
