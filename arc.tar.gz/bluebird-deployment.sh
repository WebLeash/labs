#!/usr/bin/env bash

workspace=$(pwd)

DATE=`date "+%d-%h-%Y"`;export DATE

: "${BB_DEPLOYER_USER:=DEFAULT_VALUE}"
: "${BB_DEPLOYER_PASSWORD:=DEFAULT_VALUE}"
: "${GO_PIPELINE_LABEL:=DEFAULT_VALUE}"



environment_name=""
application_name=""
organization_name=""
application_rpm_name=""

usage()
{
cat << EOF
usage: $0 options

Chef Deployment script.


ENV VARS:

 GO_PIPELINE_LABEL                                 : the app version number being installed.

OPTIONS:
  
  -e : Environment                                 : (e.g. bbuk_idams_app_env_dev )
  -a : Application Name                            : (e.g. idams )
  -o : Organization Name                           : (e.g. it-intl-it-uk-id-non-prod)
  -r : Application RPM name                        : (e.g. idams-rpm)
EOF
}

while getopts e:a:o:r: option; do
    case "$option" in
	    e) environment_name=$OPTARG;;
		a) application_name=$OPTARG;;
		o) organization_name=$OPTARG;;
		r) application_rpm_name=$OPTARG;;
	    ?) usage
           exit 1;;
    esac
done

if [ -z "${environment_name}" -o -z "${application_name}"  -o -z "${organization_name}" -o -z "${application_rpm_name}" ] ; then
    usage
    exit 1
fi

cat << EOF

    Standard deployments for BlueBird.

    GoCD label ....... ${GO_PIPELINE_LABEL}

    Environment name .....  ${environment_name}
    Application name .......${application_name}
	Organization Name ..... ${organization_name}
	Application RPM name ...${application_rpm_name}
    
EOF

#Exporting required variables for Chef 

export NODE_NAME=$BB_DEPLOYER_USER
export CLIENT_KEY=~/.chef/${NODE_NAME}_chef_key.pem
export VAL_CLIENT_NAME=${organization_name}
export VAL_KEY=~/.chef/${organization_name}-validator
export CHEF_SERVER_URL=https://chef-server.app.c9.equifax.com/organizations/${organization_name}
export OS_USERNAME=$BB_DEPLOYER_USER
export NEXUS3_USERNAME=$NEXUS3_USERNAME
export NEXUS3_PASSWORD=$NEXUS3_PASSWORD


version_id=`~/build-scripts/nexus-find-rpm.py -n ${application_rpm_name} -v ${GO_PIPELINE_LABEL} --getVersion`

    if [  $? -ne 0 ]; then
        echo "Can't find Version Id for application ${application_rpm_name}"
        exit -1
    fi


cd "${workspace}"

echo "Tidying the workspace"
rm -f server_nodes failed_nodes_list app_server_list

echo "Running from ${workspace}"

env_short_name="${environment_name##*_}"

#default the blue-green flag to false
bg_flag="false"

bg_flag=`scl enable rh-ruby23 "ruby ~/chef-scripts/environment_control/bin/get_bg_env.rb bbuk_haproxy_env_${application_name}_${env_short_name};"`

    if [ $? -ne 0 ] ; then
       echo "blue-green flag not found, using default value"
    fi

if [ "$bg_flag" = "true" -o "$bg_flag" = "1" ] ; then
   
    echo "It is a Blue-Green environment"   
    active_region=`scl enable rh-ruby23 "ruby ~/chef-scripts/environment_control/bin/get_live_sub_env.rb bbuk_haproxy_env_${application_name}_${env_short_name} ${application_name};"`
	

    echo "Active Region is : $active_region"
    if [ "${active_region}" = "blue" ];then
         active_env="green"
    else
         active_env="blue"

    fi
	echo "$active_env"
    environment_name="${environment_name}_${active_env}"
    echo "environment name is: ${environment_name}"
else
   echo "Its not Blue-Green environment"
fi

log_file=$(pwd)/"$HOSTNAME".deployment."$DATE".log
echo "Updating the application version for environment : ${environment_name}"
scl enable rh-ruby23 "ruby ~/chef-scripts/environment_control/bin/set_app_version.rb ${environment_name} ${application_name} ${version_id};"

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not update the application version."
    exit 1
fi

#Check node availability in Chef
knife search node -i chef_environment:$environment_name 2>/dev/null >server_nodes;
node_count=`cat server_nodes|wc -l`
      if [ $node_count -eq 0 ] ; then
         echo "No Nodes available."
         exit 1
	  fi
	  
#check each node is reachable

echo "Hosts available in this environment (no:s) : "$node_count" "
echo "Hosts available in this environment" && cat server_nodes

for host in `cat server_nodes`

do
  
                #****** Get Ip of the Node from knife command.
                        Ip=(`knife node show $host -a ipaddress | grep ipaddress | sed -e 's/ //g' | cut -d ":" -f 2`)
                        echo " IP is : $Ip"
                        nc -z -w2 $Ip 22 2>/dev/null
						Check=$( echo $? )
                        if [[ $Check == 1 ]]; then
                         echo "Connection to Client $host ($Ip) Failed"
						 echo "$host" >> failed_nodes_list
                        else
                         echo ""$host" is reachable"
						 echo "$host" >> app_server_list 
                        fi                  

done

for app_server in `cat app_server_list`
do
   echo "Updating the application on each nodes"
   knife ssh chef_node\ name:$app_server -a ipaddress -p 22 -t 30 -x $BB_DEPLOYER_USER -P $BB_DEPLOYER_PASSWORD "sudo chef-client" > $log_file 2>&1
   knife ssh chef_node\ name:$app_server -a ipaddress -p 22 -t 30 -x $BB_DEPLOYER_USER -P $BB_DEPLOYER_PASSWORD "rpm -qa |grep $application_rpm_name" > app_version_installed 2>&1
   
    if [[ $? -ne 0 ]] ; then
       echo "ABORTING. Deployment failed."
       exit 1
    fi
	
	if [[ " $( cat "$log_file" ) " =~ "Chef Client failed" ]] ; then
	  echo "ABORTING. Deployment failed."
      exit 1
    fi	
	
   cat $log_file | grep -E "Chef Client finished" 
   cat app_version_installed | grep -E $application_rpm_name
   echo "Deployment to node $app_server is complete"

done

exit 0;