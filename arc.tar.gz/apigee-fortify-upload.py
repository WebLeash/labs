#!/bin/env python

import argparse
import os

from buildRunner import cmdRunner
from helpers     import *
from nexus_get_artifact import getNexusAuth, getArtifact

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Upload apigee artifact to Fortify on Demand.')
parser.add_argument('-n', '--name',             default='')
parser.add_argument('-v', '--version',          default='')
parser.add_argument('-t', '--type',             default='')
parser.add_argument('-r', '--repository',       default='')
parser.add_argument('-g', '--group-id',         default='')
parser.add_argument('-a', '--artifact-id',      default='')
parser.add_argument('-b', '--fod-build-token',  default='')
parser.add_argument('-s', '--source-repo',      default='')
parser.add_argument('-S', '--source-only',      default=False, type=str2bool)
parser.add_argument('-Z', '--repackage-as-zip', default=False, type=str2bool)
options = vars(parser.parse_args())

################################################################################
# Get environment and common variables

dctVariables = {
    "HPFOD_USERNAME":    "fortifyUser",
    "HPFOD_PASSWORD":    "fortifyPass",
    "PROXY_USER":        "webProxyUser",
    "PROXY_PASSWORD":    "webProxyPass",
    "GO_PIPELINE_LABEL": "pipelineLabel",
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"}

envVars    = getEnvironmentVars(dctVariables)
commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Upload artifact to HP FOD.

    Running from {2} with options.

    GoCD label ....... {1[pipelineLabel]}

    Package name ..... {0[name]}
    Package version .. {0[version]}
    Package type ..... {0[type]}
    Package repository {0[repository]}
    Package group .... {0[group_id]}
    Package artifact . {0[artifact_id]}

    FOD BSI Token .... {0[fod_build_token]}
\n'''.format(options, envVars, workDir)
print(strOut)

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

################################################################################

# Get the nexus artifact ..

nexusAuth = getNexusAuth(envVars['nexusUser'], envVars['nexusPass'])
coords    = { 'g': options['group_id'], 'a': options['name'], 'v': options['version'] }

if(getArtifact(options['repository'], coords, options['type'], nexusAuth) != 0):
    exit(1)

# Rename the file and list the contents

zipName = '{0[a]}-{0[v]}.{1}'.format(coords, options['type'])

os.rename(zipName, 'file_to_upload.zip')

print('\nList contents of zip file\n')

zipInfo('file_to_upload.zip')

# Upload to Fortify

cmdLine = 'java -Dhttps.protocols="TLSv1.2" -Djdk.tls.client.protocols="TLSv1.2" ' \
        '-jar "/var/go/FodUpload_{0[fod_version]}.jar" ' \
        '-bsiToken "{2[fod_build_token]}" -zipLocation "file_to_upload.zip" ' \
        '-userCredentials "{1[fortifyUser]}" "{1[fortifyPass]}" ' \
        '-entitlementPreference "Subscription" -scanPreferenceId "Standard" ' \
        '-proxy "{0[fod_proxy]}" "{1[webProxyUser]}" "{1[webProxyPass]}"'
cmdLine = cmdLine.format(commonVars, envVars, options)

cmdRunner(workDir, workEnv, cmdLine, 'Upload to Fortify')

# Remove the upload file

os.remove('file_to_upload.zip')
