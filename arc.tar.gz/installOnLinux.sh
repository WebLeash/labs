#!/usr/bin/env bash

########################################################################################################
# script name: installOnLinux.sh
# Description: This script will install micro service RPM into *nix VM's
# Parameters : This shell script can accept 4 parameters
#       -a : Application Name                                : (e.g. - http-cache-server )
#       -v : version                                         : (e.g. - 1.0.0 )
#       -e : Environment                                     : (e.g. - test )
#       -s : Service Name (optional)                         : (e.g. - http-cache-server )
#       -p : Environment Properties File Path (optional)     : (e.g. - /opt/esg/config/profile.properties )
#		-L : Liquibase Properties File Path(optional)  : (e.g. /opt/esg/config/esg-insurance.properties)
#		-R : RPM repo  : (e.g. uk-rpm-release|sp-rpm-releases)
#		-H : manage HAProxy? (e.g. - Y/N)
# Needed these parameters when there is a Legacy application deployment
#       -l : Is it a legacy application deployment? : (e.g. - Y/N)
#		-c : config name : (e.g. - sf-xmlcpulink-config-packaging)
#		-h : Primary servername from haproxy config(backend/servername) : (e.g. xmlcpulink/xmlcpulink_1)
#		-n : Tomcat server name
#		-t : isTomcat? (e.g. - Y/N)
#		-A : Application RPM location
#		-C : Config RPM location
########################################################################################################


###############################################################################
#
# fun_print()
# Description : Echo messages which current date
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to be formatted with date
#
###############################################################################

fun_print() {
	message=$1
	echo "`date` : $message"
}
###############################################################################
# End of fun_print()
###############################################################################



###############################################################################
# check_and_enable_zypper_repo()
# Description : Checks and enables uk-prometheus channel repo using zypper
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   environment       Environment on which application needs to be deployed
###############################################################################
check_and_enable_zypper_repo() {
	repo_id='ukdc-'
	repo_url='http://prometheus.ntg.equifax.com/ukdc-'
	echo $1

	if [ "$1" = "dev" -o "$1" = "acceptance" -o "$1" = "test" -o "$1" = "capacity" ]; then
		prometheus_channel="qa"
		elif [ "$1" = "cit" ]; then
			prometheus_channel="uat"
		else
			prometheus_channel=$1
	fi
	
	repo_id=$repo_id$prometheus_channel
	repo_url=$repo_url$prometheus_channel
	repo_url+="/x86_64/ukdc-"
	repo_url=$repo_url$prometheus_channel
	repo_url+="-repo-1.0.0-1.noarch.rpm"
	
	# repo check
	repo_check=`zypper lr -u | grep "$repo_id"  | wc -l`

	# add repo
	if [ "$repo_check" = "0" ]; then
		sudo zypper ar $repo_url $repo_id
	fi

	# enable repo
	sudo zypper mr -e $repo_id
}
###############################################################################
# End of check_and_enable_zypper_repo()
###############################################################################


###############################################################################
# add_yum_repo()
# Description : Adds uk-prometheus repo using yum
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   environment       Environment on which application needs to be deployed
###############################################################################
add_yum_repo() {
	repo_rpm_url='http://repo.devcentral.equifax.com/yum/content/repositories/uk-rpm-releases/com/equifax/rpm/repository/uk-prometheus-el6-'
	echo $1
	if [ "$1" = "dev" -o "$1" = "acceptance" -o "$1" = "test" -o "$1" = "capacity" ]; then
		prometheus_channel="qa"
		elif [ "$1" = "cit" ]; then
			prometheus_channel="uat"
		else
			prometheus_channel=$1
	fi
	
	repo_rpm_url=$repo_rpm_url$prometheus_channel
	repo_rpm_url+="/1.0.1/uk-prometheus-el6-"
	repo_rpm_url=$repo_rpm_url$prometheus_channel
	repo_rpm_url+="-1.0.1.rpm"
	
	# Force update to ensure latest is installed.
	sudo rpm -Uvh --force $repo_rpm_url
	
}
###############################################################################
# End of add_yum_repo()
###############################################################################


###############################################################################
# clear_make_cache()
# Description : clear cache of  uk-rpm-releases repo using yum
###############################################################################
clear_make_cache() {
	#Expire Cache
	sudo yum --noplugins clean expire-cache

	#Create Cache for UK RPM Release Repo
	sudo yum --noplugins --disablerepo=* --enablerepo=$1 makecache
}
###############################################################################
# End of clear_make_cache()
###############################################################################


###############################################################################
# stop_service()
# Description : Stops the service, if given
###############################################################################
stop_service() {
	fun_print "Stopping Service $serviceName"
	if [ "$tomcatpath" != "" ]; then
		currentPID=`ps -ef | grep "$tomcatpath" | grep java | grep -v grep | sed -e's/  */\t/g' | cut -f2`;
		if [ -z "$currentPID" ]; then	
			fun_print "Stop command not required as process is not running"
		else
			fun_print "Stopping server $tomcatserver"
			sudo /sbin/service $serviceName stop
			fun_print "Waiting for service $serviceName to stop"
			timeout 90 tail --pid=$currentPID -f /dev/null
			if [ "$?" != "0" ]; then
				fun_print "Can't stop $serviceName"
				exit -1
			fi
			fun_print "Server $tomcatserver successfully stopped"
		fi
	else
		if [ "x$serviceName" != "xSKIP" ]; then
			sudo /sbin/service $serviceName stop
			if [ "$?" != "0" ]; then
				fun_print "Can't stop $serviceName"
				exit -1
			fi
		fi
	fi
}
###############################################################################
# End of stop_service()
###############################################################################


###############################################################################
# start_service()
# Description : Starts the service, if given
###############################################################################
start_service() {
	fun_print "Starting Service $serviceName"
	
	if [ "$tomcatpath" != "" ]; then
		currentpidcheckflag=`ps -ef | grep "$tomcatpath" | grep java | grep -v grep | wc -l`
		if [ "$currentpidcheckflag" = "0" ]; then
			sudo /sbin/service $serviceName start
		fi
		
		fun_print "Waiting for 90 second(s) for server start"
		sleep 90
		
		currentpidcheckflag=`ps -ef | grep "$tomcatpath" | grep java | grep -v grep | wc -l`
		if [ "$currentpidcheckflag" = "0" ]; then
			fun_print "Server not started, please check the logs"
			exit -1
		fi
		
		fun_print "If everything is started properly, then printing the pid of the process"
		currentpid=`ps -ef | grep "$tomcatpath" | grep java | grep -v grep | awk '{print $2}'`
		fun_print "$tomcatserver is running with pid : $currentpid"
	else
		if [ "x$serviceName" != "xSKIP" ]; then
			sudo /sbin/service $serviceName start
			if [ "$?" != "0" ]; then
				fun_print "Can't start $serviceName"
				exit -1
			fi
		fi
	fi
}
###############################################################################
# End of start_service()
###############################################################################


###############################################################################
# installRPM()
# Description : Install an RPM file
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   appName           Name of the application
# 2.   rpmName           Name of the application / config RPM
# 3.   version           Version of the RPM to install
###############################################################################

installRPM() {
	rpmFileName="/tmp/appDeploy/${1}/${3}/${2}-${3}.rpm"
	echo "Installing RPM from '${rpmFileName}'"

	if [ "$useYum" = true ]; then
		sudo yum -y --noplugins --disablerepo=* --enablerepo=ukdc-* install $rpmFileName
	else
		sudo zypper --non-interactive install -f $rpmFileName
	fi

	if [ "$?" != "0" ]; then
		fun_print "Installation of $2 RPM Installation failed"
		exit -1
	fi

	# Check status of RPM installation
	installStatus=`rpm -qa --qf="$query_fmt" | grep $2 | awk '{print $2}' `
	if [ "$installStatus" != "" -a "$installStatus" != " " ]; then
		fun_print "$installStatus is now installed in this server."
	else
		fun_print "Some thing went wrong during installation of RPM"
		exit -1
	fi
}

###############################################################################
# End of installRPM()
###############################################################################


###############################################################################
# installRPM()
# Description : Install an RPM file
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   rpmName           Name of the RPM (application / config Name)
###############################################################################

removeRPM() {
	fun_print "Removing $1"
	if [ "$useYum" = true ]; then
		sudo yum -y --noplugins --disablerepo=* remove $1
	else
		sudo zypper --non-interactive remove $1
	fi

	if [ "$?" != "0" ]; then
		fun_print "Can't remove $1"
		exit -1
	fi
}

###############################################################################
# End of removeRPM()
###############################################################################


###############################################################################
# enable_haproxy_server()
# Description : Enable the haproxy server
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   haproxyServer      Haproxy server name
###############################################################################
enable_haproxy_server() {
	# Start Haproxy primary server
	fun_print "Enabling Haproxy server $1"
	sudo /sbin/service haproxyctl "enable server $1"
	fun_print "Waiting for 30 seconds to stop the $1 server"
	sleep 30
}
###############################################################################
# End of enable_haproxy_server()
###############################################################################


###############################################################################
# disable_haproxy_server()
# Description : Disable the haproxy server
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   haproxyServer      Haproxy server name
###############################################################################
disable_haproxy_server() {
	# Stop Haproxy primary server
	fun_print "Disabling Haproxy server $1"
	sudo /sbin/service haproxyctl "disable server $1"
	fun_print "Waiting for 30 seconds to stop the $1 server"
	sleep 30
}
###############################################################################
# End of disable_haproxy_server()
###############################################################################


commandusage="Usage: $0 -a <Application Name> -v <Version> -e <Environment> [-s <Service Name>] [-p <Environment Properties File Path>] [-l <Legacy application?>] [-c <Config RPM Name>] [-h <Haproxy server name>] [-n <Tomcat server name>]"


query_fmt='%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\t%{SUMMARY}\n'

fun_print "---------------------------------------------------------------------------------------------"
fun_print "$0 started"

# Validation of parameters
applicationName=""
version=""
serviceName=""
environment=""
profile=""
useYum=false
configName=""
haproxyServer=""
tomcatserver=""
isTomcat=""
#rpm_releases_repo="uk-rpm-releases"
liquibase_profile_path=""
manageHA="N"

while getopts a:v:e:s:p:c:h:n:t:L:H: option;
do
case $option in
	a) applicationName=$OPTARG;;
	v) version=$OPTARG;;
	e) environment=$OPTARG;;
	s) serviceName=$OPTARG;;
	p) profile=$OPTARG;;
	c) configName=$OPTARG;;
	H) manageHA=$OPTARG;;
	h) haproxyServer=$OPTARG;;
	n) tomcatserver=$OPTARG;;
	t) isTomcat=$OPTARG;;
#	R) rpm_releases_repo=$OPTARG;;
	L) liquibase_profile_path=$OPTARG;;
	?) echo $commandusage
exit 1
;;
esac
done

fun_print "Parameters for installOnLinux scripts are: "
fun_print "----------------------------------"
fun_print "applicationName : $applicationName"
fun_print "version : '$version'"
fun_print "environment : '$environment'"
fun_print "serviceName : '$serviceName'"
fun_print "profile : '$profile'"
fun_print "Config RPM Name : '$configName'"
fun_print "manage HAProxy : '$manageHA'"
fun_print "Haproxy server : '$haproxyServer'"
fun_print "Tomcat server name : '$tomcatserver'"
fun_print "IsTomcat : '$isTomcat'"
#fun_print "RPM Releases Repo is : '$rpm_releases_repo'"
fun_print "Liquibase Profile Path is : '$liquibase_profile_path'"

if [ "$isTomcat" = "Y" ]; then
	tomcatpath="/opt/tomcat-runtimes/"$tomcatserver"/"
else
	tomcatpath=""
fi

#Checking OS of target VM for installation
check_os=`cat /etc/*-release | head -1`

case "$check_os" in

SUSE*)
	fun_print "SUSE Linux found"
;;

CentOS*)
	fun_print "CentOS found"
	useYum=true
;;

?)
fun_print "Unsupported OS detected"
exit -1
;;
esac

#Add repo
#if [ "$useYum" = true ]; then
#	add_yum_repo $environment
#else
#	check_and_enable_zypper_repo $environment
#fi

#if [ "$?" != "0" ]; then
#	fun_print "Repo addition failed"
#	exit -1
#fi

##clear and make cache
#if [ "$useYum" = true ]; then
#	clear_make_cache $rpm_releases_repo
#
#	if [ "$?" != "0" ]; then
#		fun_print "WARNING Cache Clear for Repo failed."
#	fi
#fi

# Get the installed application version number and comparing it with the version that needs to be deployed 
installedversion=`rpm -qa --qf="$query_fmt" | grep $applicationName | awk '{print $1}' `
fun_print "Installed application RPM version is :  $installedversion"
fun_print "Application version to be installed is :  $version"

if [ "$installedversion" != "" -a "$installedversion" != " " ]; then
#	if [ "$rpm_releases_repo" != "sp-rpm-releases" ]; then
		if [[ "$installedversion" == *"$version"* ]]; then
			fun_print "You are trying to install a version which is already installed. So doing nothing"
			exit 0
		fi
#	fi

	# Stop Haproxy primary server
	if [ "$manageHA" = "Y" ]; then
		disable_haproxy_server $haproxyServer
	fi

	# Stop existing server
	if [ "$serviceName" != "" -a "$serviceName" != " " ]; then
		stop_service
	fi

	#Remove existing installed version
	removeRPM $installedversion
else
	fun_print "This is the first deployment of $applicationName on this server"
	
	# Stop Haproxy primary server in case there is a first time deployment of the application on the server. 
	if [ "$manageHA" = "Y" ]; then
		disable_haproxy_server $haproxyServer
	fi
fi


#Find and Install new version of config using label - start

if [ "$configName" != "" -a "$configName" != " " ]; then
	#Remove config RPM if installed
	installedconfigversion=`rpm -qa --qf="$query_fmt" | grep $configName | awk '{print $1}' `
	if [ "$installedconfigversion" != "" -a "$installedconfigversion" != " " ]; then
		if [ "$installedconfigversion" = "$version" ]; then
			fun_print "You are trying to install a version which is already installed. So doing nothing"
			exit 0
		fi
		fun_print "Installed version is : $installedconfigversion"
		#Remove existing installed version
		removeRPM $installedconfigversion
	else
		fun_print "This is the first deployment of $configName on this server"
	fi

	fun_print "Installing $version of $configName application"
	installRPM $applicationName $configName $version
fi


#Find and Install new version of application using label - start
fun_print "Installing $version of $applicationName application"
installRPM $applicationName $applicationName $version


# Write environment to profile file.
if [ ! -z "$profile" ]; then
	stdbuf -oL echo $environment > "$profile"
	if [ "$?" != "0" ]; then
		fun_print "Writing environment to profile failed"
		exit -1
	fi	
fi

# Write the liquibase context environment to application profile file.
if [ ! -z "$liquibase_profile_path" ]; then
	liquibaseContext="liquibaseContext="
	if [ "$environment" = "dev" -o "$environment" = "acceptance" -o "$environment" = "test" -o "$environment" = "qa" ]; then
		liquibaseEnvironment="acceptance"
	elif [ "$environment" = "capacity" ]; then
		liquibaseEnvironment="capacity"
	elif [ "$environment" = "cit" -o "$environment" = "uat" ]; then
		liquibaseEnvironment="cit"
	elif [ "$environment" = "prod" -o "$environment" = "production" ]; then
		liquibaseEnvironment="production"
	fi
	stdbuf -oL echo $liquibaseContext$liquibaseEnvironment > "$liquibase_profile_path"
	if [ "$?" != "0" ]; then
		fun_print "Writing liquibase to profile failed"
		exit -1
	fi	
fi


# Start new version
if [ "$serviceName" != "" -a "$serviceName" != " " ]; then
	start_service
fi

# Start Haproxy primary server
if [ "$manageHA" = "Y" ]; then
	enable_haproxy_server $haproxyServer
fi

# exit with return status as 0 - means all successfully completed
exit 0
