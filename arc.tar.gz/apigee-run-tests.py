#!/bin/env python

import argparse
import os
import sys

from nexus_get_artifact import getNexusAuth, getArtifact
from zipfile            import ZipFile
from buildRunner        import cmdRunner
from helpers            import *

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser = argparse.ArgumentParser(description='Standard test script for UK apigee Applications.')
parser.add_argument('-w', '--workspace',      default=workDir)
parser.add_argument('-a', '--approot',        default='')
parser.add_argument('-O', '--apigee-org',     default='efxeu-nonprod')
parser.add_argument('-E', '--apigee-env',     default='qa')
parser.add_argument('-P', '--apigee-proxy',   default='')
parser.add_argument('-v', '--version',        default='')
parser.add_argument('-t', '--test-tags',      default='')

options = vars(parser.parse_args())

dctVariables = {
    "PROXY_USER":        "webProxyUser",
    "PROXY_PASSWORD":    "webProxyPass",
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"
}

envVars    = getEnvironmentVars(dctVariables)
commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard test script for UK apigee Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    apigee organisation name .. {0[apigee_org]}
    apigee environment name ... {0[apigee_env]}
    apigee proxy name ......... {0[apigee_proxy]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################
# Prep the build environment

if os.name == "nt":
    workEnv['JAVA_HOME'] = 'C:\Program Files\Java\jdk1.8.0_181'
else:
    workEnv['JAVA_HOME'] = '/usr/lib/jvm/java-1.8.0'

proxyURL = buildProxyURL(commonVars['apigee_proxy_host'], 
            envVars['webProxyUser'], envVars['webProxyPass'])

workEnv['HTTP_PROXY']  = proxyURL
workEnv['HTTPS_PROXY'] = proxyURL

apigeeEnv   = options['apigee_env']
apigeeProxy = options['apigee_proxy']

################################################################################
# Download proxy bundle from Nexus

apigeeTestsName = '{0}-test-scripts'.format(apigeeProxy)

coords    = { 'g': '', 'a': apigeeTestsName, 'v': options['version'] }
nexusAuth = getNexusAuth(envVars['nexusUser'], envVars['nexusPass'])

if(getArtifact('', coords, 'zip', nexusAuth) != 0):
    exit(1)

#Unzip to tests/ folder

print('\nUnzipping test scripts')
testScriptsZip = '{0[a]}-{0[v]}.zip'.format(coords)

objZip = ZipFile(testScriptsZip, 'r')
objZip.extractall('tests')
objZip.close()

print('Test scripts unzipped\n')

# Run the tests

testDir = os.path.join(workDir, 'tests')
cmdLine = 'mvn -e -Ppipeline-deploy install  -Dapigee.env={0} -Dtags={1}'
cmdLine = cmdLine.format(apigeeEnv, options['test_tags'])

cmdRunner(testDir, workEnv, cmdLine)
