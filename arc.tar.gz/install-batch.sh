#!/usr/bin/env bash

########################################################################################################
# script name: install-batch.sh
# Description: This script will install batch application on Romeo or Elliot server.
# Parameters : This shell script can accept 3 parameters
#       1 : Deployment server details             : (e.g. - deployment server, e.g. romeo22 or elliot21 )
#       2 : Application Name                      : (e.g. - psg-audit )
#       3 : version                               : (e.g. - 1.0.0 )
#########################################################################################################

###############################################################################
#
# fun_print()
# Description : Prints line into log file
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to print in log file
#
###############################################################################

fun_print() {
  message=$1
  echo "`date` : $message" >> $log_file
}

###############################################################################
# End of fun_print()
###############################################################################

###############################################################################
#
# rc_check()
# Description: Check the return code and exit with message on failure
# Parameters:
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   message           String to print on failure
#
###############################################################################

rc_check() {
	if [ $? != 0 ] ; then

		fun_print "$@"
		exit -1
	fi
}

###############################################################################
# End of rc_check()
###############################################################################

###############################################################################
# install_batch()
# Description : Install application on the server
# Parameters :
# No.  Name              Description
# --   -------------     ------------------------------------------
# 1.   server name       Server name on which application needs to be deployed
# 2.   rpm path          Absolute RPM URL path
# 3.   username			 Username through which rpm needs to be deployed
###############################################################################

install_batch() {
  fun_print "Parameters for install_batch functions are: "
  fun_print "Server Name is : $1"
  fun_print "RPM path is : $2"
  fun_print "Username is : $3"

  # Build the ssh command line
  ssh_args="rpm -Uvh --oldpackage ${2} --ignorearch --ignoreos --replacefiles --replacepkgs"

  if [[ "$3" != svc_uk_efxbatch ]]; then
    ssh_args+=" --dbpath /home/${3}/rpm"
  fi

  fun_print "SSH command line is: ${ssh_args}"

  if [[ "$1" == *romeo* ]]; then
    ssh -T -o "StrictHostKeyChecking no" "$3"@"$1" ${ssh_args}
  else
    ssh -T -o "StrictHostKeyChecking no" "$3"@"$1" sudo ${ssh_args}
  fi

  if [ "$?" != "0" ]; then
      fun_print "Error occurred during installation of $2 on $1."
      exit -1
  fi
}

###############################################################################
# End of install_batch()
###############################################################################

# find location of scripts
scriptDir=$(dirname $0)
if [ $scriptDir = "." ]; then
	scriptDir=$(pwd)
fi

commandusage="Usage: $0 -a <Application Name> -v <Version> -d <DeployServer> -u <ApplicationUserName>"

query_fmt='%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}\t%{SUMMARY}\n'

DATE=`date "+%d-%h-%Y"`;export DATE

log_file=deployment."$DATE".log
export log_file

echo "---------------------------------------------------------------------------------------------"
echo "$0 started"

# Validation of parameters
applicationName=""
version=""
deployServer=""
appUserName=""

while getopts a:v:d:u: option;
do
case $option in
  a) applicationName=$OPTARG;;
  v) version=$OPTARG;;
  d) deployServer=$OPTARG;;
  u) appUserName=$OPTARG;;
  ?) fun_print $commandusage
exit 1
;;
esac
done

echo "Parameters"
echo "----------------------------------"
echo "applicationName : $applicationName"
echo "version : $version"
echo "deployServer: $deployServer"
echo "appUserName: $appUserName"

[[ -n "$applicationName" ]] || { fun_print "Please provide valid Application Name $commandusage" ; exit 1; }
[[ -n "$version" ]] || { fun_print "Please provide valid version $commandusage" ;  exit 1; }
[[ -n "$deployServer" ]] || { fun_print "Please provide Deployment Server Details $commandusage" ; exit 1; }
[[ -n "$appUserName" ]] || { fun_print "Please provide Application user name for rpm installation $commandusage" ; exit 1; }

# Get the Repository URL of application from yum
repo_url="$(~/build-scripts/nexus-find-rpm.py -n ${applicationName} -v ${version})"
rc_check "Unable to find RPM for ${applicationName} - ${version}"

fun_print "repo_url is : $repo_url"

# Stage the application RPM locally
fullVersion="$(~/build-scripts/nexus-find-rpm.py --getVersion -n ${applicationName} -v ${version})"
appFileName="${applicationName}-${fullVersion}.rpm"
remotePath="/tmp/appDeploy/${applicationName}/${fullVersion}"

mkdir rpm

wget -nv --no-proxy ${repo_url} -O ./rpm/${appFileName}
rc_check "Unable to download the RPM for ${applicationName} - ${version}, aborting"

# Push the staged application RPM to the remote host
ssh -T -o "StrictHostKeyChecking no" $appUserName@$deployServer "bash -s" -- < $scriptDir/prep-install.sh "-p \"${remotePath}\""
rc_check "Unable to create ${remotePath} on server ${deployServer}"

scp ./rpm/${appFileName} $appUserName@$deployServer:${remotePath}/${appFileName}
rc_check "Unable to copy RPM for ${applicationName} - ${version} to ${deployServer}"

install_batch "$deployServer" "${remotePath}/${appFileName}" "$appUserName"

# exit with return status as 0 - means all successfully completed
exit 0
