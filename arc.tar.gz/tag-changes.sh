#!/usr/bin/env bash

echo "Current Working Directory is $(pwd)"

for file in $(git diff --name-only | grep pom.xml)
do
    echo "Adding file $file"
    git add $file
done

project=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.artifactId}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting project name."
	exit 1
fi

version=$(mvn -q -Dexec.executable="echo" -Dexec.args='${project.version}' --non-recursive exec:exec)
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in getting version number"
	exit 1
fi

echo "Tagging for $project-$version"

tag=$project-$version

message=Build_$version

echo $tag

echo $message

git commit -m "$message"
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in committing to git"
	exit 1
fi

git tag -a $tag -m "$message"
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in creating a tag"
	exit 1
fi

git push origin $tag
if [ $? -ne 0 ] ; then
	echo "ABORTING. ERROR in pushing a tag"
	exit 1
fi

exit 0
