#!/usr/bin/env bash


########################################################################################################
# script name: get-region.sh
# Description: This script will provides color of a production region.
# Parameters : This shell script can accept 3 parameters
#   -u : VIPs Application URL   : (e.g. - https://war-biz-p3-esg-esp-flex-prod-proxy.app.c9.equifax.com/esg-integration-spain-flex/api )
#   -h : Header                 : (e.g. - X-App-Region )
#   -r : Region                 : (e.g. - <live|staging> )
########################################################################################################



fun_print() {
 message=$1
 echo "`date` : $message"
}


# Setup the environment
scriptDir=$(dirname $0)
if [ ${scriptDir} = "." ]; then
  scriptDir=$(pwd)
fi

DATE=`date "+%d-%h-%Y"`;export DATE

# Validation of parameters

command_usage="Usage: $0 -u <Application URL> -h <Header Name> -r <live|staging>"

url=""
header=""
region=""

while getopts u:h:r: option;
do
    case ${option} in
        u) url=$OPTARG ;;
        h) header=$OPTARG ;;
        r) region=$OPTARG ;;
        ?) fun_print "$command_usage"
           exit 1 ;;
    esac
done

if [ -z "$url" ]; then
 fun_print "Please provide valid Application URL"
 exit 1
fi

if [ -z "$header" ]; then
 fun_print "Please provide valid Header Name"
 exit 1
fi

if [ -z "$region" ]; then
 fun_print "Please provide valid Region"
 exit 1
elif ! [ "$region" = "live" -o "$region" = "staging" ]; then
 fun_print "Possible values for region are <live|staging>"
 exit 1
fi

header_value=`curl -s -i -k ${url} | grep ${header} | awk '{print $2}' | tr -d '[:space:]'`

if [ 0 -ne $? ]; then
 fun_print "Error connecting to application"
 exit 1
fi

if [ -z "$header_value" ]; then
 fun_print "Couldn't find header $header in response"
 exit 1
fi

case ${region}:${header_value} in
  live:*)
    echo ${header_value}
  ;;
  staging:blue)
    echo green
  ;;
  staging:green)
    echo blue
  ;;
  *)
    exit 1
esac
