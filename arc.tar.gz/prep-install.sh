#!/usr/bin/env bash

# 		ssh -T -o "StrictHostKeyChecking no" $userName@$host "bash -s" -- < $scriptDir/installOnLinux.sh ${ssh_args} >> $log_file 2>&1
########################################################################################################
# script name: prep-install.sh
# Description: This script will prepare the appDeploy directory on target servers for installs.
#########################################################################################################

echo "---------------------------------------------------------------------------------------------"
echo "$0 started"

installPath=""

while getopts ":p:" option; do
	case $option in
		p) installPath=$OPTARG;;
	esac
done

deployDir=/tmp/appDeploy

if [ -d ${deployDir} ]; then
	# Change permissions on the appDeploy directory
	chmod 777 ${deployDir}

	# Clear down old versions

	fileList=(`find ${deployDir} -type f -mtime +1`)

	echo "Removing ${#fileList[@]} files"

	for file in ${fileList[@]}; do
		echo " - Removing ${file}"
		rm ${file}
	done

	# Clean up any empty directories
	rmdir --ignore-fail-on-non-empty ${deployDir}/**/*
	rmdir --ignore-fail-on-non-empty ${deployDir}/*
else
	echo "Creating appDeploy directory"

	# Create the appDeploy dir and set the perms
	mkdir -p ${deployDir}
	chmod 777 ${deployDir}
fi

mkdir -p ${installPath}

exit 0
