
import requests
import os

class nexus3Search(object):
    SEARCH = 1
    FIND   = 2

    ############################################################################

    def __init__(self, nexusHost):
        self.__nexusHost = nexusHost
        self.__basicAuth = None
        self.__count     = 0
        self.__versions  = {}

    ############################################################################

    def __checkRequirements(self, intCheck):
        # Basic Auth needs to be in place for any calls
        if(self.__basicAuth == None):
            return -1

        # Drop out if we only need search requirements
        if(intCheck <= self.SEARCH):
            return 0

        # Check if there are any results to work with
        if(self.__count == 0):
            return -1

        return 0

    ############################################################################

    def __returnAsset(self, verIdx, artIdx):
        dctVersion = self.__items[verIdx]
        dctAsset   = dctVersion['assets'][artIdx]
        if('_1' in dctVersion['version']):
            dctVersion['version'] = dctVersion['version'][:-2]
        dctCoords = { 'g': dctVersion['group'],
                      'a': dctVersion['name'],
                      'v': dctVersion['version'] }
        dctReturn = { 'repository': dctAsset['repository'],
                      'coords': dctCoords,
                      'path': dctAsset['path'] }

        return dctReturn

    ############################################################################

    def __addItems(self, jsonItems):
        idx = len(self.__items)

        for item in jsonItems:
            self.__items.append(item)
            version = item['version']
            repo    = item['repository']

            # join the repo and version together and store the array index
            strVer  = '{0}~{1}'.format(repo, version)
            self.__versions[strVer] = idx
            idx = idx + 1

    ############################################################################

    def searchName(self, strName):
        # Sanity check
        if(self.__checkRequirements(self.SEARCH) < 0):
            return -1

        # Check we're searching for something
        if(strName == ''):
            return -1

        # Clean up existing cache
        self.__items    = []
        self.__versions = {}

        searchURL = 'https://{0}/service/rest/v1/search?name={1}'
        searchURL = searchURL.format(self.__nexusHost, strName)

        # Send the request to the Nexus API
        response = requests.get(searchURL, auth=self.__basicAuth)
        respJSON = response.json()

        # Check if there are any results
        self.__count = len(respJSON['items'])

        # If no results, then return 0
        if(self.__count == 0):
            return 0

        # Build an internal dictionary of versions for later
        self.__addItems(respJSON['items'])

        while(respJSON['continuationToken'] != None):
            contURL = '{0}&continuationToken={1}'.format(searchURL, respJSON['continuationToken'])

            response = requests.get(contURL, auth=self.__basicAuth)
            respJSON = response.json()

            self.__count += len(respJSON['items'])
            self.__addItems(respJSON['items'])

        return 0

    ############################################################################

    def findVersion(self, strVersion, strType = ''):
        if(self.__checkRequirements(self.FIND) <  0):
            return None

        # Filter results and store the index into __items for matching versions
        lstSearch = []
        for key, val in self.__versions.iteritems():
            if strVersion in key:
                lstSearch.append(val)

        # Search through the identified results and return a specific artifact
        for vIdx in lstSearch:
            lstAssets = self.__items[vIdx]['assets']
            for aIdx, dctAsset in enumerate(lstAssets):
                fileName, fileExt = os.path.splitext(dctAsset['path'])
                if(strType in fileExt):
                    return self.__returnAsset(vIdx, aIdx)
                    break

        return None

    ############################################################################

    @property
    def basicAuth(self):
        return None

    @basicAuth.setter
    def basicAuth(self, objAuth):
        self.__basicAuth = objAuth

    def __len__(self):
        return self.__count

    def dumpList(self):
        for strVer in self.__versions:
            print (strVer)
