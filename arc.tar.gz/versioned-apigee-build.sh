#!/usr/bin/env bash

# Make the cwd that of this script
cd "$(dirname "$0")"

workspace=$(pwd)

# The Subdirectory holding the application root - typically this is the current dir
# but may sometimes be a subdirectory if the repository is structured.
app_root_dir=""
# Do we deploy to Nexus.
deploy_to_nexus="true"
# When building, do we update the parent pom to the latest version.
update_parent="true"
# When building, do we update versions in properties to the latest version.
update_property_versions="true"
# When building, do we set a new version of the application.
update_application_version="true"
# Do we tag the changes and push back.
tag_changes="true"

source common-variables.sh

usage()
{
cat << EOF
usage: $0 options

Standard Maven build for UK Applications.

OPTIONS:
  -w               Optional. Workspace.  Defaults to script directory.
  -a               Optional. App root directory.  Defaults to current dir.
  -D [true|false]  Optional. Deploy to Nexus?  Defaults to true.
  -U [true|false]  Optional. Update the parent version?  Defaults to true.
  -P [true|false]  Optional. Update the property versions?  Defaults to true.
  -A [true|false]  Optional. Update the application version?  Defaults to true.
  -T [true|false]  Optional. Tag the change back to the repo.  Defaults to true.
EOF
}

# Get the parameters
while getopts w:d:a:D:U:P:A:T: option; do
    case "$option" in
        w) workspace=$OPTARG;;
        a) app_root_dir=$OPTARG;;
        D) deploy_to_nexus=$OPTARG;;
        U) update_parent=$OPTARG;;
        P) update_property_versions=$OPTARG;;
        A) update_application_version=$OPTARG;;
        T) tag_changes=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

if [ -z "$app_root_dir" ] ; then
    app_root_dir="${workspace}"
else
    app_root_dir="${workspace}"/"${app_root_dir}"
fi

if [ "${deploy_to_nexus}" = "deploy" -o "${deploy_to_nexus}" = "true" ] ; then
    deploy_to_nexus="true"
else
    deploy_to_nexus="false"
fi

if [ "${update_parent}" = "true" ] ; then
    update_parent="true"
else
    update_parent="false"
fi

if [ "${update_property_versions}" = "true" ] ; then
    update_property_versions="true"
else
    update_property_versions="false"
fi

if [ "${update_application_version}" = "true" ] ; then
    update_application_version="true"
else
    update_application_version="false"
fi

if [ "${tag_changes}" = "true" ] ; then
    tag_changes="true"
else
    tag_changes="false"
fi

cat << EOF

    Standard Maven build for UK Applications.

    Running from ${workspace} with options.

    App root directory ........ ${app_root_dir}
    Deploy to Nexus ........... ${deploy_to_nexus}
    Update parent version ..... ${update_parent}
    Update property versions .. ${update_property_versions}
    Update application version  ${update_application_version}
    Tag changes ............... ${tag_changes}

EOF

cd "${app_root_dir}"

# Update the parent pom version

if [ "${update_parent}" = "true" ] ; then

    mvn -e -U -B versions:update-parent

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-parent goal."
        exit 1
    fi

fi

# Update properties to the latest version of dependencies

if [ "${update_property_versions}" = "true" ] ; then

    mvn -e -U -B versions:update-properties

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-properties goal."
        exit 1
    fi

fi

# Update the main application version

if [ "${update_application_version}" = "true" ] ; then

    mvn -e versions:set

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run version:set goal."
        exit 1
    fi

fi

# Build the application and run code coverage tools using Clover.
# Requires Java 1.8.0

export JAVA_HOME="/usr/lib/jvm/java-1.8.0"

# Don't worry about "skip tests" - we have proven that tests run cleanly in the previous stage.

mvn -e install -Dmaven.test.skip=true

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not build the application."
    exit 1
fi

mvn -e org.sonarsource.scanner.maven:sonar-maven-plugin:${sonar_version}:sonar

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not run the SonarQube integration."
    exit 1
fi

# Deploy to Nexus.

if [ "${deploy_to_nexus}" = "true" ]; then

    # Force to use Maven 3.3.9 due to Nexus having proxy that doesn't like Maven 3.5.x

    temp_m2_home="${M2_HOME}"
    temp_maven_home="${MAVEN_HOME}"

    export M2_HOME="/usr/share/maven339/apache-maven-3.3.9"
    export MAVEN_HOME="/usr/share/maven339/apache-maven-3.3.9"

    mvn339 -e clean deploy -Dmaven.test.skip=true

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Could not deploy to Nexus."
        exit 1
    fi

    # Put them back again.

    export M2_HOME="${temp_m2_home}"
    export MAVEN_HOME="${temp_maven_home}"

fi

# Tag changes using the tag-changes.sh script.

if [ "${tag_changes}" = "true" ] ; then
    ~/build-scripts/tag-changes.sh "${app_root_dir}"
fi

# Tidy up.

mvn -e versions:revert

mvn -e clean

exit 0;
