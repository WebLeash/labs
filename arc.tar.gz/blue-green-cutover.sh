#!/usr/bin/env bash

workspace=$(pwd)

header=""
url=""
proxy_node_1=""
proxy_node_2=""
haproxy_189="false"
user_name=""

usage()
{
cat << EOF
usage: $0 options

Blue Green Cutover for UK Applications.

ENV VARS:

 NONE.

OPTIONS:
  -h               Optional.  The http header that will indicate if currently Blue or Green (e.g. X-App-Region).
                   If not provided, then "blue" will be assumed - this is the default - and we will flip to "green".
  -u               Optional.  The url endpoint that will return the header.  Mandatory if header is provided.
  -p               Mandatory. The first proxy server to update.
  -s               Optional.  The second proxy server to update.
  -H               Optional.  Set to true if the target server is running HAProxy 1.8.9.  Defaults to "false".
  -U               Optional.  Username to connect to HAProxy server.  Defaults to "appmgr"
                   The flip is performed differently on servers running HAProxy 1.8.9.

EOF
}

# Get the parameters
while getopts h:u:p:s:H:U: option; do
    case "$option" in
        h) header=$OPTARG;;
        u) url=$OPTARG;;
        p) proxy_node_1=$OPTARG;;
        s) proxy_node_2=$OPTARG;;
        H) haproxy_189=$OPTARG;;
        U) user_name=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

# Explicitly switched on, assume false otherwise.

if [ "${haproxy_189}" = "true" ] ; then
    haproxy_189="true"
else
    haproxy_189="false"
fi


# Verify we have at least the first proxy server

if [ -z "${proxy_node_1}" ] ; then
    usage
    exit 1
fi

# If header is not blank then url must be provided

if [ ! -z "${header}" -a -z "${url}" ] ; then
    usage
    exit 1
fi

# user_name defaults to appmgr

if [ -z "${user_name}" ] ; then
    user_name="appmgr"
fi

cat << EOF

    Blue Green Cutover for UK Applications.

    Running from ${workspace} with options.

    Header ..... ${header}
    URL ........ ${url}

    Proxy 1 .... ${proxy_node_1}
    Proxy 2 .... ${proxy_node_2}

    Username ... ${user_name}

EOF

cd "${workspace}"

# We default the target environment to "green"  (i.e. assume "blue" is the current live service).

target_env="green"

# If header and url are provided, then pull the current environment (blue or green)

if [ ! -z "${header}" -a ! -z "${url}" ] ; then

    header_value=`curl -s -i -k ${url} | grep ${header} | awk '{print $2}' | tr -d '[:space:]'`

    if [ 0 -ne $? ] ; then
        echo "ABORTING. Error connecting to ${url}"
        exit 1
    fi

    if [ -z "$header_value" ] ; then
        echo "ABORTING. Couldn't find header ${header} in response"
        exit 1
    fi

    echo "Value of ${header} in response was ${header_value}"

    # Reverse the values.  Bail out if not blue or green.

    if [ "${header_value}" = "green" ] ; then
        target_env="blue"
    elif [ "${header_value}" = "blue" ] ; then
        target_env="green"
    else
        echo "ABORTING.  We were expecting current set up to be either 'blue' or 'green'. Something is not right."
        exit 1
    fi

fi

cutover_haproxy() {

    server=$1

    echo "Begin to switch the traffic to '${target_env}' on ${server}"

    if [ "${haproxy_189}" = "true" ] ; then

        ssh -T -o "StrictHostKeyChecking no" "${user_name}@${server}" "bash -s" -- < ~/build-scripts/haproxy/haproxy-flip-189 flip ${target_env}

        if [ $? -ne 0 ] ; then
            echo "ABORTING. Error from running haproxy-flip-189 script on ${server}"
            exit 1
        fi

    else

        ssh -T -o "StrictHostKeyChecking no" "${user_name}@${server}" "bash -s" -- < ~/build-scripts/haproxy/haproxy-wrapper ${target_env}

        if [ $? -ne 0 ] ; then
            echo "ABORTING. Error from running haproxy-wrapper script on ${server}"
            exit 1
        fi

    fi

}

# Cutover on first server

cutover_haproxy "${proxy_node_1}"

# Optionally cutover on second server

if [ ! -z "${proxy_node_2}" ] ; then
    cutover_haproxy "${proxy_node_2}"
fi

# All done.

exit 0;
