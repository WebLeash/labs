#!/bin/env python

import argparse
import os
import json
import sys

from buildRunner import cmdRunner
from apigeeUtils import ApigeeUtils
from helpers     import *

workDir = os.getcwd()
workEnv = os.environ.copy()

################################################################################
# Option Parser

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

parser  = argparse.ArgumentParser(description='Standard deploy for UK apigee Applications.')
parser.add_argument('-w', '--workspace',         default=workDir)
parser.add_argument('-a', '--approot',           default='')
parser.add_argument('-O', '--apigee-org',        default='')
parser.add_argument('-E', '--apigee-env',        default='')
parser.add_argument('-P', '--apigee-proxy',      default='')
parser.add_argument('-D', '--deploy',            default=False, type=str2bool)
parser.add_argument('-N', '--use-nexus3-npm',    default=False, type=str2bool)
parser.add_argument('-n', '--npm-root-dir',      default='')

options = vars(parser.parse_args())

dctVariables = {
    "PROXY_USER":        "webProxyUser",
    "PROXY_PASSWORD":    "webProxyPass",
    "APIGEE_USER":       "apigeeUser",
    "APIGEE_PASSWORD":   "apigeePass",
    "NEXUS3_USERNAME":   "nexusUser",
    "NEXUS3_PASSWORD":   "nexusPass"
}

envVars    = getEnvironmentVars(dctVariables)
commonVars = getCommonVars()

################################################################################
# Headline summary output

strOut = '''\n
    Standard deploy for UK apigee Applications.

    Running from {0[workspace]} with options.

    App root directory ........ {0[approot]}
    apigee organisation name .. {0[apigee_org]}
    apigee environment name ... {0[apigee_env]}
    apigee proxy name ......... {0[apigee_proxy]}
    deploy proxy .............. {0[deploy]}
    NPM use Nexus 3 repository  {0[use_nexus3_npm]}
    NPM root directory ........ {0[npm_root_dir]}
\n'''.format(options)
print(strOut)

approot = os.path.join(options['workspace'], options['approot'])

################################################################################
# Initialize ApigeeUtils

proxyURL = buildProxyURL(commonVars['apigee_proxy_host'], 
            envVars['webProxyUser'], envVars['webProxyPass'])

objApigee = ApigeeUtils()
objApigee.webProxies   = { 'http': proxyURL, 'https': proxyURL }
objApigee.organisation = options['apigee_org']
objApigee.environment  = options['apigee_env']

if(not objApigee.setAuth(envVars['apigeeUser'], envVars['apigeePass'])):
    print('Authentication failed - exiting')
    sys.exit(1)

apiEnv    = options['apigee_env']
proxyName = options['apigee_proxy']

################################################################################

# Load state

strFile = '{0}.state'.format(options['apigee_org'])

print('Loading deploy state from {0}'.format(strFile))

try:
    with open(strFile, 'r') as objFile:
        proxyState = json.load(objFile)
except Exception as error:
    print('failed to open file:\n\t{0}'.format(error))
    sys.exit(0)

previousRev = proxyState['previousRevision'][apiEnv]
targetRev   = proxyState['targetRevision']

# Check which revision is currently deployed (sanity checks)

print('Finding currently deployed revision')

currentRev = objApigee.findProxyRevision(apiEnv, proxyName)

if(currentRev is None):
    print('Unable to find proxy {0} in {1} environment - exiting'.format(proxyName, apiEnv))
    sys.exit(1)

if(isinstance(currentRev, list)):
    print("Something isn't right - multiple versions deployed ({0})".format(currentRev))
    sys.exit(1)

# If the proxy doesn't exist, then exit as we can't do anything else

if(currentRev == -1):
    print("Proxy {0} doesn't exist in the Apigee organisation".format(proxyName))
    sys.exit(0)

# Decide how to revert to the previous state

if(previousRev == 0):
    # Proxy was previously not deployed
    if(currentRev > 0):
        print('Undeploying proxy {0} ({1}) from environment {2}'.format(proxyName, currentRev, apiEnv))
        objResp = objApigee.undeployRevision(apiEnv, proxyName, currentRev)

        if(objResp is None):
            print('Undeploy failed - exiting')
            sys.exit(1)

    else:
        print('Proxy {0} already at revision {1}'.format(proxyName, currentRev))

elif(currentRev <> previousRev):
    # Proxy was deployed - redeploy the previous revision
    if(currentRev > 0):
        print('Undeploying proxy {0} ({1}) from environment {2}'.format(proxyName, currentRev, apiEnv))
        objResp = objApigee.undeployRevision(apiEnv, proxyName, currentRev)

        if(objResp is None):
            print('Undeploy failed - exiting')
            sys.exit(1)

    # Deploy previous revision
    print('Deploying proxy {0} ({1}) to environment {2}'.format(proxyName, previousRev, apiEnv))
    objResp = objApigee.deployApiRevision(apiEnv, proxyName, previousRev)

    if(objResp is None):
        print('Deploy failed - exiting')
        sys.exit(1)

else:
    print('Proxy {0} already at revision {1}'.format(proxyName, currentRev))

# If we're not rolling back a deploy, that's all folks ...

if(not options['deploy']):
    print('Completed rollback successfully')
    sys.exit(0)

################################################################################

# Handle deploy clean-up

if(proxyState['newProxy']):
    # Delete proxy
    print('This script does not currently delete a proxy on rollback')
    print(' - Please delete manually')
else:
    # Delete revision
    print('Deleting revision {0}'.format(targetRev))
    objResp = objApigee.deleteApiRevision(proxyName, targetRev)

    if(objResp is None):
        print('Failed to delete the revision')
        sys.exit(1)

    print('Deleted revision')
