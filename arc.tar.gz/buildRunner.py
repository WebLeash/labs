import os
import sys
import codecs
import subprocess
from time import sleep

################################################################################
###                                                                          ###
### This code has been tested on Windows and Linux, on 2.6 / 2.7 / 3.6 / 3.7 ###
###                                                                          ###
### The first part of the file provides non-blocking pipe functionality      ###
###  and has various sections to cater for variations between environments   ###
###                            (HERE BE DRAGONS!)                            ###
###                                                                          ###
### The rest of the file provides a command runner with output pass-through  ###
###  to the console.                                                         ###
###                                                                          ###
################################################################################

if os.name == "nt":
    def pipe_non_blocking_set(pipefd):
        import msvcrt

        from ctypes import windll, byref, wintypes, WinError, POINTER
        from ctypes.wintypes import HANDLE, DWORD, BOOL

        LPDWORD = POINTER(DWORD)

        PIPE_NOWAIT = wintypes.DWORD(0x00000001)

        SetNamedPipeHandleState = windll.kernel32.SetNamedPipeHandleState
        SetNamedPipeHandleState.argtypes = [HANDLE, LPDWORD, LPDWORD, LPDWORD]
        SetNamedPipeHandleState.restype = BOOL

        h = msvcrt.get_osfhandle(pipefd)

        res = SetNamedPipeHandleState(h, byref(PIPE_NOWAIT), None, None)
        if res == 0:
            print(WinError())
            return False
        return True

    def pipe_non_blocking_is_error_blocking(ex):
        if not isinstance(ex, PortableBlockingIOError):
            return False
        from ctypes import GetLastError
        ERROR_NO_DATA = 232

        return (GetLastError() == ERROR_NO_DATA)

    PortableBlockingIOError = OSError

else:
    import errno

    def pipe_non_blocking_set(fd):
        import fcntl
        fl = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
        return True

    if sys.version_info[0] > 2:

        def pipe_non_blocking_is_error_blocking(ex):
            if not isinstance(ex, PortableBlockingIOError):
                return False
            return True

        PortableBlockingIOError = BlockingIOError

    else:

        def pipe_non_blocking_is_error_blocking(ex):
            if not isinstance(ex, PortableBlockingIOError):
                return False
            if not ex.errno in _blocking_errnos:
                return False
            return True

        PortableBlockingIOError = OSError
        _blocking_errnos = set([errno.EAGAIN, errno.EWOULDBLOCK])

################################################################################
# non blocking handler to return lines from a pipe

def non_blocking_readlines(f, chunk=1024):
    '''
    '''

    fd = f.fileno()
    pipe_non_blocking_set(fd)

    arrLines  = []
    strBuffer = b''

    while True:
        # Read from file and handle a non-blocking exception gracefully
        try:
            readBuffer = os.read(fd, chunk)
        except PortableBlockingIOError as ex:
            if not pipe_non_blocking_is_error_blocking(ex):
                raise ex

            yield b''
            continue

        # Return any remaining data if EOF, otherwise concatenate to main buffer
        if not readBuffer:
            yield b'' + strBuffer
        else:
            strBuffer += readBuffer

        # Split the received data into a line array
        posEnd = 0
        while True:
            posStart = posEnd
            posEnd   = strBuffer.find(b'\n', posStart) + 1

            if posEnd == 0:
                strBuffer = strBuffer[posStart:]
                break

            arrLines.append(strBuffer[posStart:posEnd])

        # Provide a line when requested
        while len(arrLines) > 0:
            yield b'' + arrLines.pop(0)

################################################################################
# Console output handler for byte encoded data

sysEncoding = sys.stdout.encoding

if not sysEncoding:
    sysEncoding = 'utf-8'

if hasattr(sys.stdout, 'buffer'):
    sysWriter = codecs.getwriter(sysEncoding)(sys.stdout.buffer, 'strict')
else:
    sysWriter = codecs.getwriter(sysEncoding)(sys.stdout)

def consoleWrite(strErr, strOut):
    binText = strErr.decode(sysEncoding, 'replace')
    sizeOut = len(binText)
    sysWriter.write(binText)

    binText  = strOut.decode(sysEncoding, 'replace')
    sizeOut += len(binText)
    sysWriter.write(binText)

    return sizeOut

################################################################################
# Command runner

def cmdRunner(workDir, workEnv, cmdLine, strPhase=''):
    try:
        process = subprocess.Popen(cmdLine, cwd=workDir, env=workEnv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    except OSError:
        print('Error: command ({0}) could not be executed'.format(cmdLine))

    strSep = "*" * 80
    print('{0}\n\nRunning ({1})\n\n{0}'.format(strSep, cmdLine))

    iterErr = iter(non_blocking_readlines(process.stderr))
    iterOut = iter(non_blocking_readlines(process.stdout))

    while process.poll() is None:
        sizeOut = consoleWrite(next(iterErr), next(iterOut))
        if(sizeOut == 0):
            sleep(0.1)
        sys.stdout.flush()

    strOut, strErr = process.communicate()
    consoleWrite(strErr, strOut)
    sys.stdout.flush()

    if(process.returncode != 0):
        if(strPhase != ''):
            strErr = "ABORTING - {0} failed".format(strPhase)
        else:
            strErr = "ABORTING - command ({0}) failed".format(cmdLine)

        print(strErr)
        sys.exit(1)
