#!/usr/bin/env bash

# Make the cwd that of this script
cd "$(dirname "$0")"

: "${PROJECT:=DEFAULT_VALUE}"
: "${REPOSITORY:=DEFAULT_VALUE}"
: "${PR_NAME_ID:=DEFAULT_VALUE}"
: "${GIT_PASSWORD:=DEFAULT_VALUE}"

workspace=$(pwd)

# Do we update the parent pom to the latest version.
update_parent="true"
# Do we update versions in properties to the latest version.
update_property_versions="true"
# Do we perform pit mutation testing.
enable_pit_testing="false"
# At what % mutation threshold will be break the build.  0-100, where 0 means do not break the build.
pit_mutation_threshold="70"

source common-variables.sh

usage()
{
cat << EOF
usage: $0 options

Standard Maven build for Pull Requests for UK Applications.

ENV VARS:

 PROJECT           Mandatory.  Sonar plugin. The Bitbucket project.
 REPOSITORY        Mandatory.  Sonar plugin. The Bitbucket repository.
 PR_NAME_ID        Mandatory.  Sonar plugin. The ENV VAR containing the ID for the PR.
 GIT_PASSWORD      Mandatory.  Sonar plugin. The password for publishing issue list to Bitbucket.
                                             (SonarQube holds the username).

OPTIONS:
  -m [0-100]       Optional. PIT Mutation Threshold.  Value 0-100.
  -w               Optional. Workspace.  Defaults to script directory.
  -M [true|false]  optional. Enable PIT testing?  Defaults to false.
  -P [true|false]  Optional. Update the property versions?  Defaults to true.
  -U [true|false]  Optional. Update the parent version?  Defaults to true.

EOF
}

# Get the parameters
while getopts w:m:U:P:M: option; do
    case "$option" in
        w) workspace=$OPTARG;;
        m) pit_mutation_threshold=$OPTARG;;
        M) enable_pit_testing=$OPTARG;;
        P) update_property_versions=$OPTARG;;
        U) update_parent=$OPTARG;;
        ?) usage
           exit 1;;
    esac
done

if [ "${update_parent}" = "true" ] ; then
    update_parent="true"
else
    update_parent="false"
fi

if [ "${update_property_versions}" = "true" ] ; then
    update_property_versions="true"
else
    update_property_versions="false"
fi

if [ "${enable_pit_testing}" = "true" ] ; then
    enable_pit_testing="true"
else
    enable_pit_testing="false"
fi

cat << EOF

    Standard Maven build for Pull Requests for UK Applications.

    Running from ${workspace} with options.

    Update parent version ..... ${update_parent}
    Update property versions .. ${update_property_versions}

    Enable PIT Mutation Tests . ${enable_pit_testing}
    PIT Mutation Threshold % .. ${pit_mutation_threshold}

    Environment variables.

    Bitbucket project ......... ${PROJECT}
    Bitbucket repository ...... ${REPOSITORY}
    Bitbucket PR Number ....... ${!PR_NAME_ID}

EOF

if [ -z "${!PR_NAME_ID}" -o "${PR_NAME_ID}" = "DEFAULT_VALUE" -o "${PROJECT}" = "DEFAULT_VALUE" -o "${REPOSITORY}" = "DEFAULT_VALUE" ] ; then
    echo "ABORTING. Environment variables have not been configured correctly in the GoCD pipeline."
    exit 1
fi

cd "${workspace}"

# Update the parent pom version

if [ "${update_parent}" = "true" ] ; then

    mvn -e -U -B versions:update-parent

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-parent goal."
        exit 1
    fi

fi

# Update properties to the latest version of dependencies

if [ "${update_property_versions}" = "true" ] ; then

    mvn -e -U -B versions:update-properties

    if [ $? -ne 0 ] ; then
        echo "ABORTING. Versions plugin. Could not run update-properties goal."
        exit 1
    fi

fi

# Build the application and run code coverage tools using Clover.
# Requires Java 1.8.0

export JAVA_HOME="/usr/lib/jvm/java-1.8.0"

mvn -e clean org.openclover:clover-maven-plugin:${clover_version}:setup verify org.openclover:clover-maven-plugin:${clover_version}:aggregate org.openclover:clover-maven-plugin:${clover_version}:clover

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not build the application."
    exit 1
fi

if [ "${enable_pit_testing}" = "true" ] ; then
    git_commit="$(git show --format="%h" --no-patch)"

    # Run PIT Tests. Moved to start to allow the results to be picked up by SonarQube.

    mvn -e org.pitest:pitest-maven:1.4.0:scmMutationCoverage -DoutputFormats=XML,HTML -DoriginBranch=${git_commit} -DdestinationBranch="origin/master" -DmutationThreshold=${pit_mutation_threshold}

    if [ $? -ne 0 ] ; then
        echo "ABORTING. PIT testing failed."
        exit 1
    fi
fi

# Don't worry about "skip tests" - we have proven that tests run cleanly in the previous stage.

mvn -e install -Dmaven.test.skip=true

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not build the application."
    exit 1
fi

mvn -e org.sonarsource.scanner.maven:sonar-maven-plugin:${sonar_version}:sonar -Dsonar.analysis.mode="preview" -Dsonar.stash.notification -Dsonar.stash.project="${PROJECT}" -Dsonar.stash.repository="${REPOSITORY}" -Dsonar.stash.pullrequest.id="${!PR_NAME_ID}" -Dsonar.stash.password="${GIT_PASSWORD}" -Dsonar.clover.reportPath="target/site/clover/clover.xml"

if [ $? -ne 0 ] ; then
    echo "ABORTING. Could not run the SonarQube integration."
    exit 1
fi

# Create the Pit Report Directory if it doesn't exist. This will be exposed as an artefact.
mkdir -p target/pit-reports

exit 0;
